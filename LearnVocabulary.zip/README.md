# Learn Vocabulary

Native Android app (Kotlin, Jetpack Compose, Material 3) that teaches English
words with Bengali meanings. Fully offline: the app has no INTERNET permission.

## Data license (GPL-3.0)

The bundled word list (`app/src/main/assets/words.json`) is derived from
**BengaliDictionary by Minhas Kamal**, licensed under **GPL-3.0**.
Distributing this app together with that data means the combined work must
comply with GPL-3.0 (provide source, keep the license and credits).

## Setup

1. Put your `words.json` at `app/src/main/assets/words.json`.
2. Build with Android Studio or GitHub Actions.

## Build

- Android Studio: open the folder, let Gradle sync, then Build > Build APK(s)
  or Run on a device (minSdk 24).
- GitHub Actions: push to `main`; download the `learn-vocabulary-release-apk`
  artifact from the workflow run.

The release APK is signed with the debug key so it installs directly.
Use your own keystore before publishing to a store.
