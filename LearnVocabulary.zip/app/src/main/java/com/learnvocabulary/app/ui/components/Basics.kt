package com.learnvocabulary.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.learnvocabulary.app.R
import com.learnvocabulary.app.ui.LVIcons
import com.learnvocabulary.app.ui.theme.darken
import com.learnvocabulary.app.ui.theme.headFont
import com.learnvocabulary.app.ui.theme.levelColor
import com.learnvocabulary.app.ui.theme.lv

@Composable
fun levelName(l: Int): String = when (l) {
    0 -> stringResource(R.string.lvl_easy)
    1 -> stringResource(R.string.lvl_medium)
    2 -> stringResource(R.string.lvl_hard)
    else -> stringResource(R.string.lvl_very_hard)
}

/** Duolingo-like chunky button with a darker 4dp bottom edge that presses down. */
@Composable
fun ChunkyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = lv.accent,
    textColor: Color = lv.onAccent,
    edge: Color = color.darken(),
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val shape = RoundedCornerShape(14.dp)
    val c = if (enabled) color else color.copy(alpha = 0.4f)
    val e = if (enabled) edge else edge.copy(alpha = 0.4f)
    Box(modifier.height(56.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .align(Alignment.BottomCenter)
                .background(e, shape)
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .offset(y = if (pressed) 4.dp else 0.dp)
                .background(c, shape)
                .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                if (icon != null) {
                    Icon(icon, null, tint = textColor, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(text, color = textColor, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
            }
        }
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    ChunkyButton(text, onClick, modifier, color = lv.card, textColor = lv.accent, edge = lv.line, enabled = enabled)
}

@Composable
fun LVCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    var m = modifier.clip(shape).background(lv.card).border(1.dp, lv.line, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun AlertCard(
    colors: List<Color>,
    title: String,
    text: String,
    onClick: (() -> Unit)?,
    textColor: Color = Color.White,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(18.dp)
    var m = modifier.fillMaxWidth().clip(shape).background(Brush.horizontalGradient(colors))
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = textColor, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(text, color = textColor.copy(alpha = 0.92f), fontSize = 14.sp)
    }
}

@Composable
fun LVChip(
    text: String,
    selected: Boolean,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
    color: Color = lv.accent
) {
    val shape = RoundedCornerShape(12.dp)
    var m = modifier
        .clip(shape)
        .background(if (selected) color.copy(alpha = 0.18f) else Color.Transparent)
        .border(1.dp, if (selected) color else lv.line, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m.padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            color = if (selected) color else lv.ink,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
fun LevelChips(override: Int, onToggle: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (l in 0..3) {
            LVChip(levelName(l), override == l, { onToggle(l) }, color = levelColor(l, lv))
        }
    }
}

@Composable
fun SpeakerButton(onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = lv.accent) {
    IconButton(onClick = onClick, modifier = modifier.size(40.dp)) {
        Icon(LVIcons.Speaker, stringResource(R.string.cd_speak), tint = tint)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(top = 8.dp, bottom = 2.dp),
        color = lv.ink,
        fontFamily = headFont,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
    )
}

@Composable
fun MutedText(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, color = lv.muted, fontSize = 14.sp, fontStyle = FontStyle.Normal)
}

@Composable
fun CountTile(title: String, count: Int, onClick: () -> Unit, color: Color, modifier: Modifier = Modifier) {
    LVCard(modifier = modifier, onClick = onClick) {
        Text(count.toString(), color = color, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 28.sp)
        Text(title, color = lv.ink, fontSize = 14.sp)
    }
}
