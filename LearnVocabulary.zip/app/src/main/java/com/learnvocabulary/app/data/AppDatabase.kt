package com.learnvocabulary.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        WordEntity::class, ProgressEntity::class, DayStatEntity::class,
        CaughtEntity::class, MetaEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
}
