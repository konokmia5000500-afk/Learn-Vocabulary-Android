package com.learnvocabulary.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.learnvocabulary.app.ui.theme.lv

@Composable
fun LogoMark(s: Dp = 56.dp) {
    val outer = lv.accent
    val inner = lv.gold
    Box(Modifier.size(s), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val d = this.size.minDimension
            val sw = d * 0.06f
            drawCircle(outer, radius = d / 2f - sw / 2f, style = Stroke(sw))
            drawCircle(inner, radius = d / 2f - sw * 2.4f, style = Stroke(sw * 0.6f))
        }
        Text("LV", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = (s.value * 0.3f).sp, color = outer)
    }
}

@Composable
fun LogoFull(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        LogoMark(60.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.width(IntrinsicSize.Max)) {
            Text("Learn", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 28.sp, color = lv.ink)
            Text(
                "Vocabulary",
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontSize = 22.sp,
                color = lv.accent
            )
            Box(Modifier.fillMaxWidth().height(1.dp).background(lv.gold))
        }
    }
}
