package com.learnvocabulary.app.notify

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.MainActivity
import com.learnvocabulary.app.R
import com.learnvocabulary.app.localized

object Notifier {
    const val CHANNEL = "reminders"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, ctx.getString(R.string.channel_name), NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun show(ctx: Context, kind: Int, title: String, body: String) {
        val route = if (kind == ReminderScheduler.KIND_LEARN) "learn" else "quiz"
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, 100 + kind, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        val nm = NotificationManagerCompat.from(ctx)
        if (nm.areNotificationsEnabled()) {
            try {
                nm.notify(300 + kind, n)
            } catch (_: SecurityException) {
            }
        }
    }

    /** Called from the alarm receiver (already on a background thread). */
    suspend fun fire(appCtx: Context, kind: Int) {
        val repo = (appCtx.applicationContext as LearnApp).repo
        val s = repo.store.current()
        val on = if (kind == ReminderScheduler.KIND_LEARN) s.learnOn else s.quizOn
        if (!on) return
        try {
            createChannel(appCtx)
            val lc = appCtx.localized(s.lang)
            if (kind == ReminderScheduler.KIND_LEARN) {
                if (!repo.goalDoneToday()) {
                    val info = repo.learnInfo()
                    if (info != null) {
                        show(
                            appCtx, kind,
                            lc.getString(R.string.notif_learn_title),
                            lc.getString(
                                R.string.notif_learn_body,
                                info.slideNo, info.perDay, info.word, info.meaning, info.today
                            )
                        )
                    }
                }
            } else {
                if (!repo.quizPlayedToday()) {
                    show(
                        appCtx, kind,
                        lc.getString(R.string.notif_quiz_title),
                        lc.getString(R.string.notif_quiz_body, repo.quizNo())
                    )
                }
            }
        } finally {
            // always schedule the next day's alarm
            if (kind == ReminderScheduler.KIND_LEARN) {
                ReminderScheduler.schedule(appCtx, kind, s.learnH, s.learnM)
            } else {
                ReminderScheduler.schedule(appCtx, kind, s.quizH, s.quizM)
            }
        }
    }
}
