package com.learnvocabulary.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "words", indices = [Index("z"), Index("custom")])
data class WordEntity(
    @PrimaryKey val id: Int,
    val w: String,
    /** meanings joined by '|' */
    val b: String,
    val e: String,
    val z: Double,
    val custom: Boolean
)

@Entity(
    tableName = "progress",
    indices = [Index("learned"), Index("again"), Index("later"), Index("mistake"), Index("lvlOverride")]
)
data class ProgressEntity(
    @PrimaryKey val wordId: Int,
    val learned: Boolean = false,
    val learnedDay: String = "",
    val again: Boolean = false,
    val later: Boolean = false,
    val mistake: Boolean = false,
    /** -1 = none, 0..3 = Easy..Very hard */
    val lvlOverride: Int = -1,
    val box: Int = 0,
    val ok: Int = 0,
    val bad: Int = 0,
    val seen: Boolean = false,
    /** -1 = never quizzed, 0 = last wrong, 1 = last right */
    val lastOk: Int = -1
)

@Entity(tableName = "day_stats")
data class DayStatEntity(
    @PrimaryKey val day: String,
    val l0: Int = 0,
    val l1: Int = 0,
    val l2: Int = 0,
    val l3: Int = 0,
    val qOk: Int = 0,
    val qBad: Int = 0
)

@Entity(tableName = "caught")
data class CaughtEntity(@PrimaryKey val day: String)

@Entity(tableName = "meta")
data class MetaEntity(@PrimaryKey val k: String, val v: String)

/** Joined word + progress row with the effective level. */
data class WordRow(
    val id: Int,
    val w: String,
    val b: String,
    val e: String,
    val z: Double,
    val custom: Boolean,
    val learned: Boolean,
    val again: Boolean,
    val later: Boolean,
    val mistake: Boolean,
    val lvlOverride: Int,
    val box: Int,
    val ok: Int,
    val bad: Int,
    val seen: Boolean,
    val lastOk: Int,
    val lvl: Int
) {
    val meanings: List<String> get() = b.split('|').filter { it.isNotBlank() }
    val main: String get() = meanings.firstOrNull() ?: ""
}

data class LvlCount(val lvl: Int, val total: Int, val learned: Int)
data class LvlUnlearned(val lvl: Int, val c: Int)
data class ListCounts(
    val ov0: Int, val ov1: Int, val ov2: Int, val ov3: Int,
    val again: Int, val later: Int, val mistake: Int
)
data class QuizStats(val ok: Int, val bad: Int, val nq: Int)

object Q {
    const val LVL =
        "CASE WHEN p.lvlOverride>=0 THEN p.lvlOverride WHEN w.custom=1 THEN 1 " +
            "WHEN w.z>=4.6 THEN 0 WHEN w.z>=3.6 THEN 1 WHEN w.z>=3.0 THEN 2 ELSE 3 END"
    const val SEL =
        "SELECT w.id AS id, w.w AS w, w.b AS b, w.e AS e, w.z AS z, w.custom AS custom, " +
            "p.learned AS learned, p.again AS again, p.later AS later, p.mistake AS mistake, " +
            "p.lvlOverride AS lvlOverride, p.box AS box, p.ok AS ok, p.bad AS bad, " +
            "p.seen AS seen, p.lastOk AS lastOk, (" + LVL + ") AS lvl " +
            "FROM words w JOIN progress p ON p.wordId = w.id"
}
