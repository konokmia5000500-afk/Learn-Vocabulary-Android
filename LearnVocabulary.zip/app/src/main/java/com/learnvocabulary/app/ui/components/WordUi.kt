package com.learnvocabulary.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.WordRow
import com.learnvocabulary.app.ui.LVIcons
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.theme.headFont
import com.learnvocabulary.app.ui.theme.levelColor
import com.learnvocabulary.app.ui.theme.lv

fun highlighted(text: String, word: String, color: Color): AnnotatedString = buildAnnotatedString {
    val r = Regex("\\b" + Regex.escape(word) + "\\w*", RegexOption.IGNORE_CASE)
    var last = 0
    for (m in r.findAll(text)) {
        append(text.substring(last, m.range.first))
        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = color)) { append(m.value) }
        last = m.range.last + 1
    }
    append(text.substring(last))
}

@Composable
fun WordRowItem(
    row: WordRow,
    onClick: () -> Unit,
    onSpeak: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(row.w, color = lv.ink, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(row.meanings.take(2).joinToString(" · "), color = lv.muted, fontSize = 14.sp, maxLines = 1)
        }
        if (row.learned) {
            Icon(LVIcons.Check, stringResource(R.string.cd_learned), tint = lv.good, modifier = Modifier.size(20.dp))
        }
        trailing?.invoke()
        SpeakerButton(onSpeak)
    }
}

class SheetState {
    var listKind by mutableStateOf<Int?>(null)
    var wordId by mutableStateOf<Int?>(null)
}

@Composable
fun rememberSheetState(): SheetState = remember { SheetState() }

@Composable
fun listTitle(kind: Int): String = when (kind) {
    in 0..3 -> levelName(kind)
    10 -> stringResource(R.string.list_again)
    11 -> stringResource(R.string.list_later)
    12 -> stringResource(R.string.list_mistakes)
    else -> levelName(kind - 20)
}

@Composable
fun Sheets(state: SheetState, main: MainViewModel, goLearn: () -> Unit) {
    val kind = state.listKind
    if (kind != null) {
        ListSheet(
            kind = kind,
            main = main,
            reloadKey = state.wordId,
            onDismiss = { state.listKind = null },
            onWord = { state.wordId = it },
            onStudy = {
                state.listKind = null
                main.studyKind(kind) { goLearn() }
            }
        )
    }
    val id = state.wordId
    if (id != null) {
        WordSheet(
            id = id,
            main = main,
            onDismiss = { state.wordId = null },
            onLearnNow = {
                state.wordId = null
                state.listKind = null
                main.learnNow(id) { goLearn() }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListSheet(
    kind: Int,
    main: MainViewModel,
    reloadKey: Any?,
    onDismiss: () -> Unit,
    onWord: (Int) -> Unit,
    onStudy: () -> Unit
) {
    var words by remember(kind) { mutableStateOf<List<WordRow>?>(null) }
    var studyCount by remember(kind) { mutableStateOf(0) }
    LaunchedEffect(kind, reloadKey) {
        words = main.repo.listWords(kind)
        studyCount = main.repo.studyCount(kind)
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = lv.card
    ) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding()) {
            Text(listTitle(kind), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Spacer(Modifier.height(8.dp))
            val list = words
            if (list != null && list.isEmpty()) {
                MutedText(stringResource(R.string.no_words))
            }
            LazyColumn(Modifier.heightIn(max = 460.dp)) {
                items(list ?: emptyList(), key = { it.id }) { row ->
                    WordRowItem(row, onClick = { onWord(row.id) }, onSpeak = { main.speak(row, false) })
                }
            }
            Spacer(Modifier.height(12.dp))
            ChunkyButton(
                stringResource(R.string.study_n, studyCount),
                onStudy,
                Modifier.fillMaxWidth(),
                enabled = studyCount > 0
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WordSheet(id: Int, main: MainViewModel, onDismiss: () -> Unit, onLearnNow: () -> Unit) {
    val flow = remember(id) { main.repo.wordFlow(id) }
    val row by flow.collectAsStateWithLifecycle(null)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = lv.card
    ) {
        val r = row
        Column(
            Modifier.padding(horizontal = 16.dp).navigationBarsPadding().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (r == null) {
                MutedText(stringResource(R.string.no_words))
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        r.w, color = lv.ink, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold,
                        fontSize = 32.sp, modifier = Modifier.weight(1f)
                    )
                    SpeakerButton({ main.speak(r, true) })
                }
                LVChip(
                    stringResource(R.string.level_label, levelName(r.lvl)), true, null,
                    color = levelColor(r.lvl, lv)
                )
                r.meanings.forEachIndexed { i, m ->
                    Text(
                        m,
                        color = if (i == 0) lv.accent else lv.muted,
                        fontSize = if (i == 0) 24.sp else 17.sp,
                        fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Normal
                    )
                }
                if (r.e.isNotBlank()) {
                    Text(
                        highlighted(r.e, r.w, lv.accent),
                        color = lv.ink, fontStyle = FontStyle.Italic, fontSize = 16.sp
                    )
                }
                LevelChips(r.lvlOverride) { l -> main.setOverride(r.id, if (r.lvlOverride == l) -1 else l) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.learn_later), color = lv.ink, modifier = Modifier.weight(1f))
                    Switch(
                        checked = r.later,
                        onCheckedChange = { main.setLater(r.id, it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = lv.accent, checkedThumbColor = lv.onAccent)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    SecondaryButton(stringResource(R.string.close), onDismiss, Modifier.weight(1f))
                    ChunkyButton(stringResource(R.string.learn_now), onLearnNow, Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
