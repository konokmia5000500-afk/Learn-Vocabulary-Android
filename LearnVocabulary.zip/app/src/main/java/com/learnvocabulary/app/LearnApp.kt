package com.learnvocabulary.app

import android.app.Application
import android.content.ComponentCallbacks2
import androidx.room.Room
import com.learnvocabulary.app.data.AppDatabase
import com.learnvocabulary.app.data.Repo
import com.learnvocabulary.app.data.SettingsStore
import com.learnvocabulary.app.notify.Notifier
import com.learnvocabulary.app.tts.TtsManager

class LearnApp : Application() {
    lateinit var db: AppDatabase
        private set
    lateinit var repo: Repo
        private set
    lateinit var tts: TtsManager
        private set

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, AppDatabase::class.java, "learn_vocabulary.db").build()
        repo = Repo(this, db, SettingsStore(this))
        tts = TtsManager(this)
        tts.init()
        Notifier.createChannel(this)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // Release the speech engine when the app is far in the background; it re-initializes on next use.
        if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) tts.shutdown()
    }
}
