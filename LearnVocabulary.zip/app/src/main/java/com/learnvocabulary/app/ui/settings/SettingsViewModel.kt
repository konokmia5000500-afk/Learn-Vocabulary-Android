package com.learnvocabulary.app.ui.settings

import android.app.Application
import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.BackupData
import com.learnvocabulary.app.data.BackupManager
import com.learnvocabulary.app.data.Settings
import com.learnvocabulary.app.notify.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ImportPlan(val data: BackupData)

class SettingsViewModel(private val app: Application) : AndroidViewModel(app) {
    private val la = app as LearnApp
    private val repo = la.repo
    val settings = repo.settings
    val messages = MutableSharedFlow<Int>(extraBufferCapacity = 4)
    val importPlan = MutableStateFlow<ImportPlan?>(null)

    fun update(f: (Settings) -> Settings) {
        viewModelScope.launch {
            repo.store.update(f)
            ReminderScheduler.syncAll(app, repo.store.current())
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            repo.store.update { it.copy(lang = lang) }
            applyLocale(lang)
        }
    }

    private fun applyLocale(lang: String) {
        val cur = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        if (!cur.startsWith(lang)) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(lang))
        }
    }

    fun refreshVoices(accent: String) = la.tts.refresh(accent)

    fun testVoice(s: Settings) {
        la.tts.speak("Hello, this is a test.", "এটি একটি পরীক্ষা", s)
    }

    fun export(uri: Uri) {
        viewModelScope.launch {
            try {
                val text = repo.exportData()
                withContext(Dispatchers.IO) {
                    app.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("no stream")
                }
                messages.emit(R.string.export_ok)
            } catch (e: Exception) {
                messages.emit(R.string.export_error)
            }
        }
    }

    fun prepareImport(uri: Uri) {
        viewModelScope.launch {
            try {
                val data = withContext(Dispatchers.IO) {
                    val text = app.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("no stream")
                    BackupManager.parse(text)
                }
                importPlan.value = ImportPlan(data)
            } catch (e: Exception) {
                messages.emit(R.string.import_error)
            }
        }
    }

    fun cancelImport() {
        importPlan.value = null
    }

    fun confirmImport() {
        val plan = importPlan.value ?: return
        importPlan.value = null
        viewModelScope.launch {
            try {
                repo.applyBackup(plan.data)
                ReminderScheduler.syncAll(app, repo.store.current())
                messages.emit(R.string.import_ok)
                applyLocale(plan.data.settings.lang)
            } catch (e: Exception) {
                messages.emit(R.string.import_error)
            }
        }
    }

    fun reset() {
        viewModelScope.launch {
            try {
                repo.resetAll()
                ReminderScheduler.syncAll(app, repo.store.current())
                messages.emit(R.string.reset_ok)
            } catch (e: Exception) {
                messages.emit(R.string.import_error)
            }
        }
    }
}
