package com.learnvocabulary.app.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

data class Settings(
    val lang: String = "en",
    val theme: String = "system",
    val font: String = "classic",
    val textSize: Int = 16,
    val perDay: Int = 10,
    val autoSpeak: Boolean = false,
    val speakBn: Boolean = false,
    val accent: String = "us",
    val rate: Float = 1f,
    val pitch: Float = 1f,
    val learnOn: Boolean = false,
    val learnH: Int = 20,
    val learnM: Int = 0,
    val quizOn: Boolean = false,
    val quizH: Int = 20,
    val quizM: Int = 30
)

class SettingsStore(private val ctx: Context) {
    private val kLang = stringPreferencesKey("lang")
    private val kTheme = stringPreferencesKey("theme")
    private val kFont = stringPreferencesKey("font")
    private val kTextSize = intPreferencesKey("textSize")
    private val kPerDay = intPreferencesKey("perDay")
    private val kAuto = booleanPreferencesKey("autoSpeak")
    private val kBn = booleanPreferencesKey("speakBn")
    private val kAccent = stringPreferencesKey("accent")
    private val kRate = floatPreferencesKey("rate")
    private val kPitch = floatPreferencesKey("pitch")
    private val kLearnOn = booleanPreferencesKey("learnOn")
    private val kLearnH = intPreferencesKey("learnH")
    private val kLearnM = intPreferencesKey("learnM")
    private val kQuizOn = booleanPreferencesKey("quizOn")
    private val kQuizH = intPreferencesKey("quizH")
    private val kQuizM = intPreferencesKey("quizM")

    val flow: Flow<Settings> = ctx.dataStore.data.map { read(it) }

    suspend fun current(): Settings = flow.first()

    suspend fun update(f: (Settings) -> Settings) {
        ctx.dataStore.edit { p -> write(p, f(read(p))) }
    }

    private fun read(p: Preferences): Settings {
        val d = Settings()
        return Settings(
            lang = p[kLang] ?: d.lang,
            theme = p[kTheme] ?: d.theme,
            font = p[kFont] ?: d.font,
            textSize = p[kTextSize] ?: d.textSize,
            perDay = p[kPerDay] ?: d.perDay,
            autoSpeak = p[kAuto] ?: d.autoSpeak,
            speakBn = p[kBn] ?: d.speakBn,
            accent = p[kAccent] ?: d.accent,
            rate = p[kRate] ?: d.rate,
            pitch = p[kPitch] ?: d.pitch,
            learnOn = p[kLearnOn] ?: d.learnOn,
            learnH = p[kLearnH] ?: d.learnH,
            learnM = p[kLearnM] ?: d.learnM,
            quizOn = p[kQuizOn] ?: d.quizOn,
            quizH = p[kQuizH] ?: d.quizH,
            quizM = p[kQuizM] ?: d.quizM
        )
    }

    private fun write(p: MutablePreferences, s: Settings) {
        p[kLang] = s.lang
        p[kTheme] = s.theme
        p[kFont] = s.font
        p[kTextSize] = s.textSize
        p[kPerDay] = s.perDay
        p[kAuto] = s.autoSpeak
        p[kBn] = s.speakBn
        p[kAccent] = s.accent
        p[kRate] = s.rate
        p[kPitch] = s.pitch
        p[kLearnOn] = s.learnOn
        p[kLearnH] = s.learnH
        p[kLearnM] = s.learnM
        p[kQuizOn] = s.quizOn
        p[kQuizH] = s.quizH
        p[kQuizM] = s.quizM
    }
}
