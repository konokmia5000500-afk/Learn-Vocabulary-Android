package com.learnvocabulary.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RawQuery
import androidx.sqlite.db.SupportSQLiteQuery
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // ---- inserts ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(l: List<WordEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertProgress(l: List<ProgressEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(p: ProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgressList(l: List<ProgressEntity>)

    // ---- words ----
    @Query("SELECT * FROM progress WHERE wordId=:id")
    suspend fun progress(id: Int): ProgressEntity?

    @Query("SELECT COUNT(*) FROM words")
    fun totalWords(): Flow<Int>

    @Query("SELECT id FROM words")
    suspend fun allIds(): List<Int>

    @Query(Q.SEL + " WHERE w.id=:id")
    fun wordFlow(id: Int): Flow<WordRow?>

    @Query(Q.SEL + " WHERE w.id=:id")
    suspend fun word(id: Int): WordRow?

    @Query(Q.SEL + " WHERE w.id IN (:ids)")
    suspend fun wordsByIds(ids: List<Int>): List<WordRow>

    @Query(
        "SELECT w.id FROM words w JOIN progress p ON p.wordId=w.id " +
            "WHERE p.learned=0 AND p.later=0 AND w.id!=:ex " +
            "ORDER BY p.again DESC, w.custom DESC, w.z DESC, w.id ASC LIMIT :n"
    )
    suspend fun dailyIds(n: Int, ex: Int): List<Int>

    @RawQuery
    suspend fun rawWords(q: SupportSQLiteQuery): List<WordRow>

    @RawQuery
    suspend fun rawIds(q: SupportSQLiteQuery): List<Int>

    @Query(
        Q.SEL + " WHERE p.learned=0 AND p.later=0 AND (p.seen=1 OR p.again=1) " +
            "ORDER BY p.again DESC, w.z DESC LIMIT 20"
    )
    fun continueWords(): Flow<List<WordRow>>

    @Query(
        Q.SEL + " WHERE p.learned=0 AND p.later=0 " +
            "ORDER BY p.again DESC, w.custom DESC, w.z DESC, w.id ASC LIMIT 12"
    )
    fun upNext(): Flow<List<WordRow>>

    @Query(
        "SELECT COALESCE(SUM(CASE WHEN lvlOverride=0 THEN 1 ELSE 0 END),0) AS ov0, " +
            "COALESCE(SUM(CASE WHEN lvlOverride=1 THEN 1 ELSE 0 END),0) AS ov1, " +
            "COALESCE(SUM(CASE WHEN lvlOverride=2 THEN 1 ELSE 0 END),0) AS ov2, " +
            "COALESCE(SUM(CASE WHEN lvlOverride=3 THEN 1 ELSE 0 END),0) AS ov3, " +
            "COALESCE(SUM(CASE WHEN again=1 THEN 1 ELSE 0 END),0) AS again, " +
            "COALESCE(SUM(CASE WHEN later=1 THEN 1 ELSE 0 END),0) AS later, " +
            "COALESCE(SUM(CASE WHEN mistake=1 THEN 1 ELSE 0 END),0) AS mistake FROM progress"
    )
    fun listCounts(): Flow<ListCounts>

    @Query(
        "SELECT lvl, COUNT(*) AS c FROM (SELECT (" + Q.LVL + ") AS lvl FROM words w " +
            "JOIN progress p ON p.wordId=w.id WHERE p.learned=0 AND p.later=0) GROUP BY lvl"
    )
    fun unlearnedByLevel(): Flow<List<LvlUnlearned>>

    @Query(
        "SELECT lvl, COUNT(*) AS total, COALESCE(SUM(learned),0) AS learned FROM (SELECT (" + Q.LVL +
            ") AS lvl, p.learned AS learned FROM words w JOIN progress p ON p.wordId=w.id) GROUP BY lvl"
    )
    fun levelCounts(): Flow<List<LvlCount>>

    @Query(
        "SELECT COALESCE(SUM(CASE WHEN lastOk=1 THEN 1 ELSE 0 END),0) AS ok, " +
            "COALESCE(SUM(CASE WHEN mistake=1 THEN 1 ELSE 0 END),0) AS bad, " +
            "COALESCE(SUM(CASE WHEN lastOk=-1 THEN 1 ELSE 0 END),0) AS nq " +
            "FROM progress WHERE learned=1"
    )
    fun quizStats(): Flow<QuizStats>

    @Query(Q.SEL + " WHERE p.bad>0 ORDER BY p.bad DESC, w.z DESC LIMIT 5")
    fun mostMissed(): Flow<List<WordRow>>

    // ---- progress updates ----
    @Query("UPDATE progress SET learned=1, learnedDay=:day, again=0, later=0, seen=1 WHERE wordId=:id")
    suspend fun setLearned(id: Int, day: String)

    @Query("UPDATE progress SET again=1, seen=1 WHERE wordId=:id")
    suspend fun setAgain(id: Int)

    @Query("UPDATE progress SET later=:v WHERE wordId=:id")
    suspend fun setLater(id: Int, v: Boolean)

    @Query("UPDATE progress SET lvlOverride=:l WHERE wordId=:id")
    suspend fun setOverride(id: Int, l: Int)

    @Query("UPDATE progress SET seen=1 WHERE wordId=:id")
    suspend fun setSeen(id: Int)

    @Query("UPDATE progress SET later=0 WHERE wordId IN (:ids)")
    suspend fun clearLater(ids: List<Int>)

    @Query(
        "UPDATE progress SET learned=0, learnedDay='', again=0, later=0, mistake=0, " +
            "lvlOverride=-1, box=0, ok=0, bad=0, seen=0, lastOk=-1"
    )
    suspend fun resetProgress()

    @Query("DELETE FROM progress WHERE wordId IN (SELECT id FROM words WHERE custom=1)")
    suspend fun deleteCustomProgress()

    @Query("DELETE FROM words WHERE custom=1")
    suspend fun deleteCustomWords()

    @Query("DELETE FROM words WHERE id=:id AND custom=1")
    suspend fun deleteCustomWord(id: Int)

    @Query("DELETE FROM progress WHERE wordId=:id")
    suspend fun deleteProgress(id: Int)

    @Query("SELECT * FROM words WHERE custom=1 ORDER BY id")
    suspend fun customWordsOnce(): List<WordEntity>

    @Query("SELECT COALESCE(MAX(id),0) FROM words WHERE custom=1")
    suspend fun maxCustomId(): Int

    @Query(
        "SELECT * FROM progress WHERE learned=1 OR again=1 OR later=1 OR mistake=1 OR lvlOverride>=0 " +
            "OR box>0 OR ok>0 OR bad>0 OR seen=1"
    )
    suspend fun progressNonDefault(): List<ProgressEntity>

    @Query("SELECT COUNT(*) FROM progress WHERE learned=1")
    suspend fun learnedOnce(): Int

    // ---- days ----
    @Query("SELECT * FROM day_stats ORDER BY day")
    fun dayStats(): Flow<List<DayStatEntity>>

    @Query("SELECT * FROM day_stats ORDER BY day")
    suspend fun dayStatsOnce(): List<DayStatEntity>

    @Query("SELECT * FROM day_stats WHERE day=:d")
    suspend fun dayStat(d: String): DayStatEntity?

    @Query("INSERT OR IGNORE INTO day_stats(day,l0,l1,l2,l3,qOk,qBad) VALUES(:d,0,0,0,0,0,0)")
    suspend fun ensureDay(d: String)

    @Query("UPDATE day_stats SET l0=l0+:a, l1=l1+:b, l2=l2+:c, l3=l3+:e WHERE day=:d")
    suspend fun addLearned(d: String, a: Int, b: Int, c: Int, e: Int)

    @Query("UPDATE day_stats SET qOk=qOk+:ok, qBad=qBad+:bad WHERE day=:d")
    suspend fun addQuiz(d: String, ok: Int, bad: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDays(l: List<DayStatEntity>)

    @Query("DELETE FROM day_stats")
    suspend fun clearDays()

    @Query("SELECT day FROM caught")
    fun caught(): Flow<List<String>>

    @Query("SELECT day FROM caught")
    suspend fun caughtOnce(): List<String>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addCaught(l: List<CaughtEntity>)

    @Query("DELETE FROM caught")
    suspend fun clearCaught()

    // ---- meta ----
    @Query("SELECT v FROM meta WHERE k=:k")
    suspend fun meta(k: String): String?

    @Query("SELECT v FROM meta WHERE k=:k")
    fun metaFlow(k: String): Flow<String?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setMeta(m: MetaEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun initMeta(m: MetaEntity)

    @Query("UPDATE meta SET v = CAST(CAST(v AS INTEGER) + :d AS TEXT) WHERE k=:k")
    suspend fun addMeta(k: String, d: Int)

    @Query("DELETE FROM meta WHERE k=:k")
    suspend fun deleteMeta(k: String)
}
