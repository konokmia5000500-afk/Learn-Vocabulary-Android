package com.learnvocabulary.app.ui.home

import android.app.Application
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.ListCounts
import com.learnvocabulary.app.data.WordRow
import com.learnvocabulary.app.domain.StatsCalc
import com.learnvocabulary.app.today
import com.learnvocabulary.app.ui.LVIcons
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.components.AlertCard
import com.learnvocabulary.app.ui.components.CountTile
import com.learnvocabulary.app.ui.components.LVCard
import com.learnvocabulary.app.ui.components.LogoFull
import com.learnvocabulary.app.ui.components.SectionTitle
import com.learnvocabulary.app.ui.components.Sheets
import com.learnvocabulary.app.ui.components.levelName
import com.learnvocabulary.app.ui.components.rememberSheetState
import com.learnvocabulary.app.ui.theme.headFont
import com.learnvocabulary.app.ui.theme.levelColor
import com.learnvocabulary.app.ui.theme.lv
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

data class HomeUi(
    val total: Int = 0,
    val perDay: Int = 10,
    val todayCount: Int = 0,
    val showGoal: Boolean = false,
    val missed: List<LocalDate> = emptyList(),
    val showQuiz: Boolean = false,
    val counts: ListCounts = ListCounts(0, 0, 0, 0, 0, 0, 0),
    val slider: List<WordRow> = emptyList(),
    val upNext: Boolean = false
)

private data class Core(
    val perDay: Int,
    val todayCount: Int,
    val showGoal: Boolean,
    val missed: List<LocalDate>,
    val showQuiz: Boolean
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LearnApp).repo

    private val ticker = flow {
        while (true) {
            emit(Unit)
            delay(30_000)
        }
    }

    private val core = combine(repo.settings, repo.dayStats, repo.caught, repo.firstUse, ticker) { s, days, caught, first, _ ->
        val map = days.associateBy { it.day }
        val todayStr = today().toString()
        val tc = StatsCalc.learned(map[todayStr])
        val now = LocalTime.now()
        val remindPassed = !s.learnOn || !now.isBefore(LocalTime.of(s.learnH, s.learnM))
        val showGoal = tc < s.perDay && (remindPassed || tc > 0)
        val caughtSet = caught.toSet()
        val missed = if (first == null) emptyList() else
            StatsCalc.missedDays(LocalDate.parse(first), today(), map).filter { it.toString() !in caughtSet }
        val quizToday = StatsCalc.quizTotal(map[todayStr])
        val showQuiz = s.quizOn && !now.isBefore(LocalTime.of(s.quizH, s.quizM)) && quizToday == 0
        Core(s.perDay, tc, showGoal, missed, showQuiz)
    }

    val ui: StateFlow<HomeUi> = combine(core, repo.listCounts, repo.totalWords, repo.continueWords, repo.upNext) { c, lc, total, cont, next ->
        HomeUi(
            total = total, perDay = c.perDay, todayCount = c.todayCount, showGoal = c.showGoal,
            missed = c.missed, showQuiz = c.showQuiz, counts = lc,
            slider = if (cont.isNotEmpty()) cont else next, upNext = cont.isEmpty()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUi())
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(main: MainViewModel, navigate: (String) -> Unit, vm: HomeViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val sheets = rememberSheetState()
    val res = LocalContext.current.resources
    val loc = LocalConfiguration.current.locales[0]
    val fmt = DateTimeFormatter.ofPattern("d MMM", loc)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { LogoFull() }
        }
        item {
            LVCard(Modifier.fillMaxWidth()) {
                Text(
                    stringResource(R.string.welcome_title), color = lv.ink, fontFamily = headFont,
                    fontWeight = FontWeight.Bold, fontSize = 22.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.welcome_body, ui.total, ui.perDay),
                    color = lv.muted, fontSize = 15.sp
                )
            }
        }
        if (ui.showGoal) {
            item {
                AlertCard(
                    listOf(lv.accent, lv.gold),
                    stringResource(R.string.alert_goal_title, ui.todayCount, ui.perDay),
                    stringResource(R.string.alert_goal_text),
                    onClick = { main.continueToday { navigate("learn") } },
                    textColor = lv.onAccent
                )
            }
        }
        if (ui.missed.isNotEmpty()) {
            item {
                val shown = ui.missed.takeLast(4).reversed()
                val extra = ui.missed.size - shown.size
                val dates = shown.joinToString(", ") { it.format(fmt) } + if (extra > 0) "  +$extra" else ""
                AlertCard(
                    listOf(Color(0xFFB3362F), Color(0xFFB8892B)),
                    res.getQuantityString(R.plurals.missed_days, ui.missed.size, ui.missed.size),
                    dates,
                    onClick = { main.continueToday { navigate("learn") } }
                )
            }
        }
        if (ui.showQuiz) {
            item {
                AlertCard(
                    listOf(lv.accent, lv.gold),
                    stringResource(R.string.alert_quiz_title),
                    stringResource(R.string.alert_quiz_text),
                    onClick = { navigate("quiz") },
                    textColor = lv.onAccent
                )
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureBox(LVIcons.Learn, R.string.nav_learn, R.string.feat_learn, Modifier.weight(1f)) { navigate("learn") }
                    FeatureBox(LVIcons.Trophy, R.string.nav_quiz, R.string.feat_quiz, Modifier.weight(1f)) { navigate("quiz") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureBox(LVIcons.Score, R.string.nav_score, R.string.feat_score, Modifier.weight(1f)) { navigate("score") }
                    FeatureBox(LVIcons.Pencil, R.string.nav_words, R.string.feat_words, Modifier.weight(1f)) { navigate("words") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureBox(LVIcons.Sliders, R.string.nav_settings, R.string.feat_settings, Modifier.weight(1f)) { navigate("settings") }
                    Spacer(Modifier.weight(1f))
                }
            }
        }
        if (ui.slider.isNotEmpty()) {
            item {
                SectionTitle(
                    stringResource(if (ui.upNext) R.string.up_next else R.string.continue_title)
                )
            }
            item {
                val ls = rememberLazyListState()
                LazyRow(
                    state = ls,
                    flingBehavior = rememberSnapFlingBehavior(ls),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(ui.slider, key = { it.id }) { row ->
                        LVCard(
                            Modifier.width(220.dp),
                            onClick = { main.learnNow(row.id) { navigate("learn") } }
                        ) {
                            Text(row.w, color = lv.ink, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 1)
                            Text(row.main, color = lv.accent, fontSize = 16.sp, maxLines = 1)
                            Spacer(Modifier.height(6.dp))
                            Text(levelName(row.lvl), color = levelColor(row.lvl, lv), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item { SectionTitle(stringResource(R.string.my_lists)) }
        item {
            val c = ui.counts
            val tiles = listOf(
                Triple(levelName(0), c.ov0, 0), Triple(levelName(1), c.ov1, 1),
                Triple(levelName(2), c.ov2, 2), Triple(levelName(3), c.ov3, 3),
                Triple(stringResource(R.string.list_again), c.again, 10),
                Triple(stringResource(R.string.list_later), c.later, 11),
                Triple(stringResource(R.string.list_mistakes), c.mistake, 12)
            )
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                tiles.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        pair.forEach { (title, count, kind) ->
                            val col = if (kind in 0..3) levelColor(kind, lv) else lv.accent
                            CountTile(title, count, { sheets.listKind = kind }, col, Modifier.weight(1f))
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
    Sheets(sheets, main) { navigate("learn") }
}

@Composable
private fun FeatureBox(icon: ImageVector, title: Int, desc: Int, modifier: Modifier, onClick: () -> Unit) {
    LVCard(modifier, onClick = onClick) {
        Icon(icon, null, tint = lv.accent, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(stringResource(title), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(stringResource(desc), color = lv.muted, fontSize = 13.sp)
    }
}
