package com.learnvocabulary.app.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getIntExtra(ReminderScheduler.EXTRA_KIND, 0)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Notifier.fire(context.applicationContext, kind)
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }
    }
}
