package com.learnvocabulary.app.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.Settings
import com.learnvocabulary.app.ui.LVIcons
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.components.ChunkyButton
import com.learnvocabulary.app.ui.components.LogoFull
import com.learnvocabulary.app.ui.components.SceneKind
import com.learnvocabulary.app.ui.components.Scenery
import com.learnvocabulary.app.ui.home.HomeScreen
import com.learnvocabulary.app.ui.learn.LearnScreen
import com.learnvocabulary.app.ui.quiz.QuizScreen
import com.learnvocabulary.app.ui.score.ScoreScreen
import com.learnvocabulary.app.ui.settings.InstallVoiceDialog
import com.learnvocabulary.app.ui.settings.SettingsScreen
import com.learnvocabulary.app.ui.theme.LearnTheme
import com.learnvocabulary.app.ui.theme.lv
import com.learnvocabulary.app.ui.words.WordsScreen
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.MutableState

private data class Tab(val route: String, val icon: ImageVector, val desc: Int, val title: Int, val scene: SceneKind)

private val tabs = listOf(
    Tab("home", LVIcons.Home, R.string.nav_home, R.string.title_home, SceneKind.Home),
    Tab("learn", LVIcons.Learn, R.string.nav_learn, R.string.title_learn, SceneKind.Learn),
    Tab("score", LVIcons.Score, R.string.nav_score, R.string.title_score, SceneKind.Score),
    Tab("words", LVIcons.Pencil, R.string.nav_words, R.string.title_words, SceneKind.Words),
    Tab("quiz", LVIcons.Trophy, R.string.nav_quiz, R.string.title_quiz, SceneKind.Quiz),
    Tab("settings", LVIcons.Sliders, R.string.nav_settings, R.string.title_settings, SceneKind.Settings)
)

@Composable
fun AppRoot(main: MainViewModel, pendingRoute: MutableState<String?>) {
    val settings by main.settings.collectAsStateWithLifecycle()
    val s = settings
    if (s == null) {
        LearnTheme(Settings()) { Box(Modifier.fillMaxSize().background(lv.bg)) }
        return
    }
    LearnTheme(s) {
        val done by main.initDone.collectAsStateWithLifecycle()
        val err by main.initError.collectAsStateWithLifecycle()
        val progress by main.initProgress.collectAsStateWithLifecycle()
        if (!done) {
            Column(
                Modifier.fillMaxSize().background(lv.bg).padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LogoFull()
                if (err != null) {
                    Text(stringResource(R.string.init_error), color = lv.bad, modifier = Modifier.padding(top = 24.dp), textAlign = TextAlign.Center)
                    Text(err ?: "", color = lv.muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(8.dp))
                    ChunkyButton(stringResource(R.string.retry), { main.retryInit() }, Modifier.padding(top = 12.dp).fillMaxWidth())
                } else {
                    Text(stringResource(R.string.importing), color = lv.muted, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp))
                    LinearProgressIndicator(
                        progress = { progress }, modifier = Modifier.fillMaxWidth(),
                        color = lv.accent, trackColor = lv.line
                    )
                }
            }
        } else {
            MainScaffold(main, pendingRoute)
        }
        val needInstall by main.tts.needInstall.collectAsStateWithLifecycle()
        if (needInstall) InstallVoiceDialog(main)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold(main: MainViewModel, pendingRoute: MutableState<String?>) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"
    val tab = tabs.firstOrNull { it.route == route } ?: tabs[0]

    fun go(r: String) {
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    val pr = pendingRoute.value
    LaunchedEffect(pr) {
        if (pr != null) {
            go(pr)
            pendingRoute.value = null
        }
    }

    Scaffold(
        containerColor = lv.bg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        smallCaps(stringResource(tab.title)),
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        color = lv.ink,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = lv.bg, titleContentColor = lv.ink)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = lv.card, tonalElevation = 0.dp) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = { go(t.route) },
                        icon = { Icon(t.icon, stringResource(t.desc), modifier = Modifier.size(24.dp)) },
                        label = null,
                        alwaysShowLabel = false,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = lv.accent,
                            unselectedIconColor = lv.muted,
                            indicatorColor = lv.accent.copy(alpha = 0.16f)
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(lv.bg)) {
            Scenery(tab.scene, Modifier.fillMaxSize())
            NavHost(navController = nav, startDestination = "home") {
                composable("home") { HomeScreen(main, ::go) }
                composable("learn") { LearnScreen(main, ::go) }
                composable("score") { ScoreScreen() }
                composable("words") { WordsScreen(main, ::go) }
                composable("quiz") { QuizScreen(main) }
                composable("settings") { SettingsScreen(main) }
            }
        }
    }
}

/** Small-caps look: first letter of each word large, the rest uppercase and smaller. */
private fun smallCaps(text: String) = buildAnnotatedString {
    var start = true
    for (ch in text) {
        if (ch.isWhitespace()) {
            append(ch); start = true
        } else if (start) {
            withStyle(SpanStyle(fontSize = 22.sp)) { append(ch.uppercaseChar()) }
            start = false
        } else {
            withStyle(SpanStyle(fontSize = 16.sp)) { append(ch.uppercaseChar()) }
        }
    }
}
