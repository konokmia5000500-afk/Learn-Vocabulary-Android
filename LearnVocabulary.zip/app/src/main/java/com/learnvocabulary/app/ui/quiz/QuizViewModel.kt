package com.learnvocabulary.app.ui.quiz

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.domain.Question
import com.learnvocabulary.app.domain.QuizEngine
import com.learnvocabulary.app.domain.QuizSetup
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

data class Feedback(val ok: Boolean, val answer: String)

data class QuizState(
    val phase: Int = 0, // 0 setup, 1 playing, 2 done
    val setup: QuizSetup = QuizSetup(),
    val loading: Boolean = false,
    val notEnough: Boolean = false,
    val questions: List<Question> = emptyList(),
    val index: Int = 0,
    val hearts: Int = 5,
    val xp: Int = 0,
    val combo: Int = 0,
    val correct: Int = 0,
    val wrong: Int = 0,
    val selected: Int = -1,
    val typed: String = "",
    val feedback: Feedback? = null,
    val matched: Set<Int> = emptySet(),
    val matchErr: Set<Int> = emptySet(),
    val selL: Int = -1,
    val selR: Int = -1,
    val flashL: Int = -1,
    val flashR: Int = -1,
    val outOfHearts: Boolean = false
) {
    val current: Question? get() = questions.getOrNull(index)
}

class QuizViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LearnApp).repo
    val state = MutableStateFlow(QuizState())
    private var busy = false

    init {
        viewModelScope.launch { state.value = state.value.copy(setup = repo.quizSetup()) }
    }

    fun updateSetup(f: (QuizSetup) -> QuizSetup) {
        val n = f(state.value.setup)
        state.value = state.value.copy(setup = n, notEnough = false)
        viewModelScope.launch { repo.saveQuizSetup(n) }
    }

    fun toSetup() {
        busy = false
        state.value = state.value.copy(phase = 0, notEnough = false)
    }

    fun start() {
        if (state.value.loading) return
        state.value = state.value.copy(loading = true, notEnough = false)
        viewModelScope.launch {
            val setup = state.value.setup
            val (pool, distract) = repo.quizPools(setup)
            val qs = QuizEngine.build(setup, pool, distract)
            if (qs.isEmpty()) {
                state.value = state.value.copy(loading = false, notEnough = true)
            } else {
                busy = false
                state.value = QuizState(phase = 1, setup = setup, questions = qs)
            }
        }
    }

    fun playAgain() = start()

    // ----- single-answer questions (MCQ, fill) -----
    fun answerChoice(i: Int) {
        val st = state.value
        val q = st.current ?: return
        if (busy || st.feedback != null || st.phase != 1) return
        busy = true
        state.value = st.copy(selected = i)
        process(q, i == q.correct)
    }

    fun setTyped(t: String) {
        if (state.value.feedback == null) state.value = state.value.copy(typed = t)
    }

    fun submitTyped() {
        val st = state.value
        val q = st.current ?: return
        if (busy || st.feedback != null || st.phase != 1 || st.typed.isBlank()) return
        busy = true
        process(q, st.typed.trim().equals(q.en, ignoreCase = true))
    }

    private fun process(q: Question, ok: Boolean) {
        viewModelScope.launch {
            repo.recordAnswer(q.wordId, ok)
            var st = state.value
            if (ok) {
                val combo = st.combo + 1
                val gain = 10 + min(5, max(0, combo - 1))
                repo.addXp(gain)
                st = st.copy(combo = combo, xp = st.xp + gain, correct = st.correct + 1)
            } else {
                st = st.copy(combo = 0, hearts = st.hearts - 1, wrong = st.wrong + 1)
                if (!q.repeat && st.questions.size < QuizEngine.MAX_QUESTIONS) {
                    st = st.copy(questions = st.questions + QuizEngine.repeatOf(q))
                }
            }
            state.value = st.copy(feedback = Feedback(ok, q.answerText))
        }
    }

    // ----- match pairs -----
    fun tapLeft(pair: Int) = tapMatch(pair, true)
    fun tapRight(pair: Int) = tapMatch(pair, false)

    private fun tapMatch(pair: Int, left: Boolean) {
        val st = state.value
        val q = st.current ?: return
        if (q.type != 4 || st.feedback != null || busy || pair in st.matched || st.flashL >= 0) return
        val l = if (left) pair else st.selL
        val r = if (left) st.selR else pair
        if (l < 0 || r < 0) {
            state.value = if (left) st.copy(selL = pair) else st.copy(selR = pair)
            return
        }
        busy = true
        viewModelScope.launch {
            var s = state.value
            if (l == r) {
                if (l !in s.matchErr) {
                    repo.recordAnswer(q.pairIds[l], true)
                    val combo = s.combo + 1
                    val gain = 10 + min(5, max(0, combo - 1))
                    repo.addXp(gain)
                    s = s.copy(combo = combo, xp = s.xp + gain, correct = s.correct + 1)
                }
                val matched = s.matched + l
                s = s.copy(matched = matched, selL = -1, selR = -1)
                state.value = if (matched.size >= 5) s.copy(feedback = Feedback(true, "")) else s
                busy = false
            } else {
                if (l !in s.matchErr) repo.recordAnswer(q.pairIds[l], false)
                val hearts = s.hearts - 1
                s = s.copy(
                    combo = 0, hearts = hearts, wrong = s.wrong + 1,
                    matchErr = s.matchErr + l, flashL = l, flashR = r
                )
                state.value = s
                delay(500)
                state.value = state.value.copy(flashL = -1, flashR = -1, selL = -1, selR = -1)
                busy = false
                if (hearts <= 0) finish(true)
            }
        }
    }

    // ----- flow -----
    fun next() {
        val st = state.value
        if (st.feedback == null) return
        busy = false
        if (st.hearts <= 0) {
            finish(true)
            return
        }
        if (st.index + 1 >= st.questions.size) {
            finish(false)
            return
        }
        state.value = st.copy(
            index = st.index + 1, selected = -1, typed = "", feedback = null,
            matched = emptySet(), matchErr = emptySet(), selL = -1, selR = -1, flashL = -1, flashR = -1
        )
    }

    private fun finish(outOfHearts: Boolean) {
        val st = state.value
        busy = false
        viewModelScope.launch {
            repo.finishQuiz(st.correct > 0)
            state.value = state.value.copy(phase = 2, outOfHearts = outOfHearts, feedback = null)
        }
    }
}
