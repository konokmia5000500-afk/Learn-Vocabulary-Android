package com.learnvocabulary.app.ui.quiz

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.learnvocabulary.app.R
import com.learnvocabulary.app.domain.Question
import com.learnvocabulary.app.ui.LVIcons
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.components.ChunkyButton
import com.learnvocabulary.app.ui.components.LVCard
import com.learnvocabulary.app.ui.components.LVChip
import com.learnvocabulary.app.ui.components.MutedText
import com.learnvocabulary.app.ui.components.SecondaryButton
import com.learnvocabulary.app.ui.components.SectionTitle
import com.learnvocabulary.app.ui.components.SpeakerButton
import com.learnvocabulary.app.ui.components.levelName
import com.learnvocabulary.app.ui.theme.headFont
import com.learnvocabulary.app.ui.theme.lv
import kotlin.math.roundToInt

@Composable
fun QuizScreen(main: MainViewModel, vm: QuizViewModel = viewModel()) {
    val st by vm.state.collectAsStateWithLifecycle()
    when (st.phase) {
        0 -> SetupView(vm, st)
        1 -> PlayView(vm, main, st)
        else -> EndView(vm, st)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SetupView(vm: QuizViewModel, st: QuizState) {
    val setup = st.setup
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionTitle(stringResource(R.string.quiz_source))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LVChip(stringResource(R.string.src_all), setup.source == 0, { vm.updateSetup { it.copy(source = 0) } })
            LVChip(stringResource(R.string.my_words), setup.source == 1, { vm.updateSetup { it.copy(source = 1) } })
        }
        SectionTitle(stringResource(R.string.quiz_difficulty))
        val diffs = listOf(
            stringResource(R.string.diff_any), levelName(0), levelName(1), levelName(2), levelName(3),
            stringResource(R.string.list_mistakes)
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            diffs.forEachIndexed { i, label ->
                LVChip(label, setup.difficulty == i, { vm.updateSetup { it.copy(difficulty = i) } })
            }
        }
        SectionTitle(stringResource(R.string.quiz_types))
        val types = listOf(
            R.string.qt_mcq_eb, R.string.qt_mcq_be, R.string.qt_fill, R.string.qt_type, R.string.qt_match
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            types.forEachIndexed { i, res ->
                val on = i in setup.types
                LVChip(stringResource(res), on, {
                    vm.updateSetup {
                        val n = if (on) it.types - i else it.types + i
                        if (n.isEmpty()) it else it.copy(types = n)
                    }
                })
            }
        }
        SectionTitle(stringResource(R.string.quiz_count))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(10, 15, 20).forEach { n ->
                LVChip(n.toString(), setup.count == n, { vm.updateSetup { it.copy(count = n) } })
            }
        }
        if (st.notEnough) {
            Text(stringResource(R.string.quiz_not_enough), color = lv.bad)
        }
        Spacer(Modifier.height(4.dp))
        ChunkyButton(
            stringResource(R.string.quiz_start), { vm.start() }, Modifier.fillMaxWidth(),
            enabled = !st.loading
        )
    }
}

@Composable
private fun PlayView(vm: QuizViewModel, main: MainViewModel, st: QuizState) {
    val q = st.current
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.toSetup() }) {
                    Icon(LVIcons.Close, stringResource(R.string.cd_close), tint = lv.ink)
                }
                LinearProgressIndicator(
                    progress = { (st.index.toFloat() / st.questions.size.coerceAtLeast(1)).coerceIn(0f, 1f) },
                    modifier = Modifier.weight(1f).height(10.dp),
                    color = lv.good, trackColor = lv.line
                )
                Spacer(Modifier.width(10.dp))
                Icon(LVIcons.Heart, null, tint = lv.bad, modifier = Modifier.size(22.dp))
                Text(" ${st.hearts}", color = lv.bad, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(LVIcons.Star, null, tint = lv.gold, modifier = Modifier.size(18.dp))
                    Text(" ${st.xp} XP", color = lv.muted, fontSize = 14.sp)
                }
                if (st.combo >= 2) {
                    Text(stringResource(R.string.combo_x, st.combo), color = lv.gold, fontWeight = FontWeight.Bold)
                }
            }
            if (q != null) {
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 140.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (q.type) {
                        0, 1, 2 -> ChoiceQuestion(vm, main, st, q)
                        3 -> TypeQuestion(vm, st, q)
                        else -> MatchQuestion(vm, st, q)
                    }
                }
            }
        }
        val fb = st.feedback
        AnimatedVisibility(
            visible = fb != null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it }
        ) {
            if (fb != null) FeedbackSheet(fb, onContinue = { vm.next() })
        }
    }
}

@Composable
private fun ChoiceQuestion(vm: QuizViewModel, main: MainViewModel, st: QuizState, q: Question) {
    val title = when (q.type) {
        0 -> R.string.q_prompt_eb
        1 -> R.string.q_prompt_be
        else -> R.string.q_prompt_fill
    }
    Text(stringResource(title), color = lv.muted, fontSize = 14.sp)
    LVCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                q.prompt, color = lv.ink, fontFamily = if (q.type == 2) FontFamily.Serif else FontFamily.Serif,
                fontWeight = FontWeight.Bold, fontSize = if (q.type == 2) 20.sp else 30.sp,
                fontStyle = if (q.type == 2) FontStyle.Italic else FontStyle.Normal,
                modifier = Modifier.weight(1f)
            )
            if (q.type == 0) SpeakerButton({ main.speakWord(q.en) })
        }
        if (q.type == 2 && q.hint.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(q.hint, color = lv.accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
    }
    q.options.forEachIndexed { i, opt ->
        val answered = st.feedback != null
        val isCorrect = i == q.correct
        val isSelected = st.selected == i
        OptionItem(
            text = opt,
            state = when {
                answered && isCorrect -> 1
                answered && isSelected -> 2
                else -> 0
            },
            shake = answered && isSelected && !isCorrect,
            onClick = { vm.answerChoice(i) }
        )
    }
}

/** state: 0 normal, 1 correct (green), 2 wrong (red) */
@Composable
private fun OptionItem(text: String, state: Int, shake: Boolean, onClick: () -> Unit) {
    val off = remember2()
    LaunchedEffect(shake) {
        if (shake) {
            repeat(3) {
                off.animateTo(12f, tween(45))
                off.animateTo(-12f, tween(45))
            }
            off.animateTo(0f, tween(45))
        }
    }
    val c = when (state) {
        1 -> lv.good
        2 -> lv.bad
        else -> lv.line
    }
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .offset { IntOffset(off.value.roundToInt(), 0) }
            .fillMaxWidth()
            .clip(shape)
            .background(if (state == 0) lv.card else c.copy(alpha = 0.15f))
            .border(2.dp, c, shape)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Text(text, color = if (state == 0) lv.ink else c, fontSize = 18.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun remember2(): Animatable<Float, androidx.compose.animation.core.AnimationVector1D> =
    androidx.compose.runtime.remember { Animatable(0f) }

@Composable
private fun TypeQuestion(vm: QuizViewModel, st: QuizState, q: Question) {
    Text(stringResource(R.string.q_prompt_type), color = lv.muted, fontSize = 14.sp)
    LVCard(Modifier.fillMaxWidth()) {
        Text(q.prompt, color = lv.accent, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 30.sp)
    }
    val answered = st.feedback != null
    OutlinedTextField(
        value = st.typed,
        onValueChange = { vm.setTyped(it) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        enabled = !answered,
        placeholder = { Text(stringResource(R.string.type_hint)) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { vm.submitTyped() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = lv.accent, unfocusedBorderColor = lv.line,
            focusedTextColor = lv.ink, unfocusedTextColor = lv.ink,
            disabledTextColor = lv.ink, disabledBorderColor = lv.line
        )
    )
    if (!answered) {
        ChunkyButton(stringResource(R.string.check), { vm.submitTyped() }, Modifier.fillMaxWidth(), enabled = st.typed.isNotBlank())
    }
}

@Composable
private fun MatchQuestion(vm: QuizViewModel, st: QuizState, q: Question) {
    Text(stringResource(R.string.q_prompt_match), color = lv.muted, fontSize = 14.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            q.leftOrder.forEach { p ->
                MatchTile(
                    q.pairEn[p], matched = p in st.matched, selected = st.selL == p,
                    wrong = st.flashL == p, serif = true
                ) { vm.tapLeft(p) }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            q.rightOrder.forEach { p ->
                MatchTile(
                    q.pairBn[p], matched = p in st.matched, selected = st.selR == p,
                    wrong = st.flashR == p, serif = false
                ) { vm.tapRight(p) }
            }
        }
    }
}

@Composable
private fun MatchTile(text: String, matched: Boolean, selected: Boolean, wrong: Boolean, serif: Boolean, onClick: () -> Unit) {
    val off = remember2()
    LaunchedEffect(wrong) {
        if (wrong) {
            repeat(3) {
                off.animateTo(10f, tween(40))
                off.animateTo(-10f, tween(40))
            }
            off.animateTo(0f, tween(40))
        }
    }
    val c = when {
        matched -> lv.good
        wrong -> lv.bad
        selected -> lv.accent
        else -> lv.line
    }
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .offset { IntOffset(off.value.roundToInt(), 0) }
            .fillMaxWidth()
            .height(60.dp)
            .clip(shape)
            .background(if (matched || wrong || selected) c.copy(alpha = 0.15f) else lv.card)
            .border(2.dp, c, shape)
            .clickable(enabled = !matched, onClick = onClick)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (matched) lv.good else lv.ink, textAlign = TextAlign.Center,
            fontFamily = if (serif) FontFamily.Serif else null, fontSize = 16.sp, maxLines = 2,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun FeedbackSheet(fb: Feedback, onContinue: () -> Unit) {
    val c = if (fb.ok) lv.good else lv.bad
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .background(c.copy(alpha = 0.16f).compositeOver(lv.card))
            .navigationBarsPadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            stringResource(if (fb.ok) R.string.fb_correct else R.string.fb_wrong),
            color = c, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 24.sp
        )
        if (!fb.ok && fb.answer.isNotBlank()) {
            Text(stringResource(R.string.fb_answer), color = lv.muted, fontSize = 13.sp)
            Text(fb.answer, color = lv.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        ChunkyButton(stringResource(R.string.continue_btn), onContinue, Modifier.fillMaxWidth(), color = c, textColor = Color.White)
    }
}

private fun Color.compositeOver(bg: Color): Color {
    val a = alpha
    return Color(
        red * a + bg.red * (1 - a),
        green * a + bg.green * (1 - a),
        blue * a + bg.blue * (1 - a),
        1f
    )
}

@Composable
private fun EndView(vm: QuizViewModel, st: QuizState) {
    val total = st.correct + st.wrong
    val acc = if (total == 0) 0 else (st.correct * 100f / total).roundToInt()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LVCard(Modifier.fillMaxWidth()) {
            Text(
                stringResource(if (st.outOfHearts) R.string.quiz_out_of_hearts else R.string.quiz_complete),
                color = if (st.outOfHearts) lv.bad else lv.good,
                fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 26.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(16.dp))
            StatLine(stringResource(R.string.stat_xp), "+${st.xp}")
            StatLine(stringResource(R.string.stat_accuracy), "$acc%")
            StatLine(stringResource(R.string.stat_correct), st.correct.toString())
            StatLine(stringResource(R.string.stat_wrong), st.wrong.toString())
            Spacer(Modifier.height(20.dp))
            ChunkyButton(stringResource(R.string.play_again), { vm.playAgain() }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            SecondaryButton(stringResource(R.string.quiz_setup), { vm.toSetup() }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        MutedText(label)
        Text(value, color = lv.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}
