package com.learnvocabulary.app.ui.words

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.WordRow
import com.learnvocabulary.app.ui.LVIcons
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.components.ChunkyButton
import com.learnvocabulary.app.ui.components.LVChip
import com.learnvocabulary.app.ui.components.MutedText
import com.learnvocabulary.app.ui.components.Sheets
import com.learnvocabulary.app.ui.components.WordRowItem
import com.learnvocabulary.app.ui.components.levelName
import com.learnvocabulary.app.ui.components.rememberSheetState
import com.learnvocabulary.app.ui.theme.lv
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch

class WordsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LearnApp).repo
    val q = MutableStateFlow("")
    val bn = MutableStateFlow(false)
    val filter = MutableStateFlow(0)
    private val reload = MutableStateFlow(0)
    val results = MutableStateFlow<List<WordRow>>(emptyList())
    val hasMore = MutableStateFlow(false)
    private var offset = 0

    companion object {
        const val PAGE = 30
    }

    @OptIn(FlowPreview::class)
    private val trigger = combine(q.debounce(200), bn, filter, reload) { a, b, c, _ -> Triple(a, b, c) }

    init {
        viewModelScope.launch {
            trigger.collectLatest { (text, isBn, f) ->
                offset = 0
                val r = repo.search(text, isBn, f, PAGE + 1, 0)
                hasMore.value = r.size > PAGE
                results.value = r.take(PAGE)
            }
        }
    }

    fun reloadNow() {
        reload.value = reload.value + 1
    }

    fun more() {
        viewModelScope.launch {
            val next = offset + PAGE
            val r = repo.search(q.value, bn.value, filter.value, PAGE + 1, next)
            offset = next
            hasMore.value = r.size > PAGE
            results.value = results.value + r.take(PAGE)
        }
    }

    fun add(word: String, meanings: String, example: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = repo.addWord(word, meanings, example)
            if (ok) reloadNow()
            onResult(ok)
        }
    }

    fun delete(id: Int) {
        viewModelScope.launch {
            repo.deleteCustom(id)
            reloadNow()
        }
    }
}

@Composable
fun WordsScreen(main: MainViewModel, navigate: (String) -> Unit, vm: WordsViewModel = viewModel()) {
    val q by vm.q.collectAsStateWithLifecycle()
    val bn by vm.bn.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val hasMore by vm.hasMore.collectAsStateWithLifecycle()
    val sheets = rememberSheetState()
    var showAdd by remember { mutableStateOf(false) }

    LaunchedEffect(sheets.wordId) { if (sheets.wordId == null) vm.reloadNow() }

    val filterLabels = listOf(
        stringResource(R.string.filter_all),
        levelName(0), levelName(1), levelName(2), levelName(3),
        stringResource(R.string.list_again), stringResource(R.string.list_later),
        stringResource(R.string.list_mistakes), stringResource(R.string.filter_learned),
        stringResource(R.string.my_words)
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                LVChip(stringResource(R.string.mode_english), !bn, { vm.bn.value = false })
                LVChip(stringResource(R.string.mode_bengali), bn, { vm.bn.value = true })
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = q,
                onValueChange = { vm.q.value = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = lv.accent, unfocusedBorderColor = lv.line,
                    focusedTextColor = lv.ink, unfocusedTextColor = lv.ink,
                    focusedContainerColor = lv.card, unfocusedContainerColor = lv.card
                )
            )
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filterLabels.size) { i ->
                    LVChip(filterLabels[i], filter == i, { vm.filter.value = i })
                }
            }
            Spacer(Modifier.height(8.dp))
            if (results.isEmpty()) {
                MutedText(stringResource(R.string.no_words), Modifier.padding(top = 16.dp))
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(results, key = { it.id }) { row ->
                    WordRowItem(
                        row,
                        onClick = { sheets.wordId = row.id },
                        onSpeak = { main.speak(row, false) },
                        trailing = if (filter == 9) {
                            {
                                IconButton(onClick = { vm.delete(row.id) }, modifier = Modifier.size(40.dp)) {
                                    Icon(LVIcons.Delete, stringResource(R.string.cd_delete), tint = lv.bad)
                                }
                            }
                        } else null
                    )
                }
                if (hasMore) {
                    item {
                        ChunkyButton(
                            stringResource(R.string.show_more), { vm.more() },
                            Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            containerColor = lv.accent,
            contentColor = lv.onAccent,
            shape = CircleShape
        ) {
            Icon(LVIcons.Add, stringResource(R.string.cd_add_word))
        }
    }

    if (showAdd) AddWordDialog(vm) { showAdd = false }
    Sheets(sheets, main) { navigate("learn") }
}

@Composable
private fun AddWordDialog(vm: WordsViewModel, onDismiss: () -> Unit) {
    var w by remember { mutableStateOf("") }
    var m by remember { mutableStateOf("") }
    var e by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = lv.accent, unfocusedBorderColor = lv.line,
        focusedTextColor = lv.ink, unfocusedTextColor = lv.ink
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = lv.card,
        title = { Text(stringResource(R.string.add_word), color = lv.ink) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    w, { w = it; error = false }, singleLine = true, colors = colors,
                    label = { Text(stringResource(R.string.field_word)) }, isError = error
                )
                OutlinedTextField(
                    m, { m = it; error = false }, colors = colors,
                    label = { Text(stringResource(R.string.field_meanings)) }, isError = error
                )
                OutlinedTextField(
                    e, { e = it }, colors = colors,
                    label = { Text(stringResource(R.string.field_example)) }
                )
                if (error) Text(stringResource(R.string.add_error), color = lv.bad)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.add(w, m, e) { ok -> if (ok) onDismiss() else error = true }
            }) { Text(stringResource(R.string.save), color = lv.accent) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = lv.muted) }
        }
    )
}
