package com.learnvocabulary.app.domain

import com.learnvocabulary.app.data.DayStatEntity
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

object Lvl {
    const val EASY = 0
    const val MEDIUM = 1
    const val HARD = 2
    const val VERY_HARD = 3
}

/** Active learning slide, persisted as JSON in the meta table. */
data class Slide(val queue: List<Int>, val total: Int, val done: Int, val finished: Boolean) {
    fun toJson(): String = JSONObject()
        .put("queue", JSONArray(queue))
        .put("total", total)
        .put("done", done)
        .put("finished", finished)
        .toString()

    companion object {
        fun parse(s: String?): Slide? {
            if (s.isNullOrBlank()) return null
            return try {
                val o = JSONObject(s)
                val a = o.getJSONArray("queue")
                Slide(List(a.length()) { a.getInt(it) }, o.getInt("total"), o.getInt("done"), o.getBoolean("finished"))
            } catch (e: Exception) {
                null
            }
        }
    }
}

data class QuizSetup(
    val source: Int = 0,            // 0 all words, 1 my words
    val difficulty: Int = 0,        // 0 any, 1..4 levels, 5 mistakes
    val types: Set<Int> = setOf(0, 1, 2, 3, 4),
    val count: Int = 10
) {
    fun encode(): String = "$source;$difficulty;${types.sorted().joinToString(",")};$count"

    companion object {
        fun decode(s: String?): QuizSetup {
            return try {
                val p = s!!.split(";")
                val t = p[2].split(",").filter { it.isNotEmpty() }.map { it.toInt() }.toSet()
                QuizSetup(p[0].toInt(), p[1].toInt(), if (t.isEmpty()) setOf(0) else t, p[3].toInt())
            } catch (e: Exception) {
                QuizSetup()
            }
        }
    }
}

object StatsCalc {
    fun learned(d: DayStatEntity?): Int = if (d == null) 0 else d.l0 + d.l1 + d.l2 + d.l3
    fun quizTotal(d: DayStatEntity?): Int = if (d == null) 0 else d.qOk + d.qBad

    /** Days after the first-use day, before today, with zero words learned. */
    fun missedDays(first: LocalDate, today: LocalDate, stats: Map<String, DayStatEntity>): List<LocalDate> {
        val out = ArrayList<LocalDate>()
        var d = first.plusDays(1)
        while (d.isBefore(today)) {
            if (learned(stats[d.toString()]) == 0) out.add(d)
            d = d.plusDays(1)
        }
        return out
    }

    fun streak(stats: Map<String, DayStatEntity>, today: LocalDate): Int {
        fun active(d: LocalDate): Boolean {
            val s = stats[d.toString()] ?: return false
            return learned(s) + quizTotal(s) > 0
        }
        var d = if (active(today)) today else today.minusDays(1)
        var n = 0
        while (active(d)) {
            n++
            d = d.minusDays(1)
        }
        return n
    }
}
