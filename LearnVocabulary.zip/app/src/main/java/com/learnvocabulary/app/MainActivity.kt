package com.learnvocabulary.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.mutableStateOf
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.nav.AppRoot

class MainActivity : AppCompatActivity() {
    private val main: MainViewModel by viewModels()
    private val pendingRoute = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) readRoute(intent)
        setContent { AppRoot(main, pendingRoute) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readRoute(intent)
    }

    private fun readRoute(i: Intent?) {
        if (i == null) return
        val route = i.getStringExtra("route") ?: i.data?.lastPathSegment
        if (route in setOf("home", "learn", "score", "words", "quiz", "settings")) pendingRoute.value = route
    }

    override fun onStop() {
        super.onStop()
        main.stopSpeak()
    }
}
