package com.learnvocabulary.app.ui.settings

import android.Manifest
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import android.speech.tts.TextToSpeech
import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.Settings
import com.learnvocabulary.app.notify.ReminderScheduler
import com.learnvocabulary.app.today
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.components.ChunkyButton
import com.learnvocabulary.app.ui.components.LVCard
import com.learnvocabulary.app.ui.components.LVChip
import com.learnvocabulary.app.ui.components.MutedText
import com.learnvocabulary.app.ui.components.SecondaryButton
import com.learnvocabulary.app.ui.theme.headFont
import com.learnvocabulary.app.ui.theme.lv
import java.util.Locale

@Composable
private fun Group(title: Int, content: @Composable () -> Unit) {
    LVCard(Modifier.fillMaxWidth()) {
        Text(stringResource(title), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, color = lv.muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun SwitchRow(text: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = if (enabled) lv.ink else lv.muted, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedTrackColor = lv.accent, checkedThumbColor = lv.onAccent)
        )
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, display: String, onDone: (Float) -> Unit) {
    var v by remember(value) { mutableStateOf(value) }
    Row(Modifier.fillMaxWidth()) {
        Label(label)
        Spacer(Modifier.weight(1f))
        Text(display, color = lv.ink, fontSize = 13.sp)
    }
    Slider(
        value = v, onValueChange = { v = it }, onValueChangeFinished = { onDone(v) },
        valueRange = range, steps = steps,
        colors = SliderDefaults.colors(thumbColor = lv.accent, activeTrackColor = lv.accent, inactiveTrackColor = lv.line)
    )
}

private fun openIntent(ctx: Context, i: Intent) {
    try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        try {
            ctx.startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(main: MainViewModel, vm: SettingsViewModel = viewModel()) {
    val ctx = LocalContext.current
    val loc = LocalConfiguration.current.locales[0]
    val s by vm.settings.collectAsStateWithLifecycle(Settings())
    val tts by main.tts.status.collectAsStateWithLifecycle()
    val plan by vm.importPlan.collectAsStateWithLifecycle()
    var tick by remember { mutableIntStateOf(0) }
    var showCustom by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.messages.collect { Toast.makeText(ctx, ctx.getString(it), Toast.LENGTH_SHORT).show() }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        tick++
        vm.refreshVoices(s.accent)
    }
    LaunchedEffect(s.accent) { vm.refreshVoices(s.accent) }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.export(uri)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.prepareImport(uri)
    }

    fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun pickTime(h: Int, m: Int, onPick: (Int, Int) -> Unit) {
        TimePickerDialog(ctx, { _, hh, mm -> onPick(hh, mm) }, h, m, DateFormat.is24HourFormat(ctx)).show()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ---------- Appearance ----------
        Group(R.string.set_appearance) {
            Label(stringResource(R.string.set_language))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LVChip("English", s.lang == "en", { vm.setLanguage("en") })
                LVChip("বাংলা", s.lang == "bn", { vm.setLanguage("bn") })
            }
            Label(stringResource(R.string.set_theme))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "system" to R.string.theme_system, "light" to R.string.theme_light, "dark" to R.string.theme_dark,
                    "sepia" to R.string.theme_sepia, "forest" to R.string.theme_forest
                ).forEach { (k, r) -> LVChip(stringResource(r), s.theme == k, { vm.update { it.copy(theme = k) } }) }
            }
            Label(stringResource(R.string.set_font))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("classic" to R.string.font_classic, "serif" to R.string.font_serif, "sans" to R.string.font_sans)
                    .forEach { (k, r) -> LVChip(stringResource(r), s.font == k, { vm.update { it.copy(font = k) } }) }
            }
            LabeledSlider(
                stringResource(R.string.set_text_size), s.textSize.toFloat(), 14f..24f, 9,
                "${s.textSize} sp"
            ) { v -> vm.update { it.copy(textSize = v.toInt().coerceIn(14, 24)) } }
        }

        // ---------- Words per day ----------
        Group(R.string.set_per_day) {
            val presets = listOf(5, 10, 15, 20, 30, 50)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { n -> LVChip(n.toString(), s.perDay == n, { vm.update { it.copy(perDay = n) } }) }
                LVChip(
                    if (s.perDay !in presets) stringResource(R.string.custom_n, s.perDay) else stringResource(R.string.custom),
                    s.perDay !in presets, { showCustom = true }
                )
            }
        }

        // ---------- Voice ----------
        Group(R.string.set_voice) {
            SwitchRow(stringResource(R.string.voice_auto), s.autoSpeak) { v -> vm.update { it.copy(autoSpeak = v) } }
            SwitchRow(
                stringResource(R.string.voice_bn), s.speakBn && tts.bn, enabled = tts.bn
            ) { v -> vm.update { it.copy(speakBn = v) } }
            if (!tts.bn) MutedText(stringResource(R.string.voice_bn_unavailable))
            Label(stringResource(R.string.voice_accent))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LVChip("US", s.accent == "us", { vm.update { it.copy(accent = "us") } })
                LVChip("UK", s.accent == "uk", { vm.update { it.copy(accent = "uk") } })
            }
            LabeledSlider(
                stringResource(R.string.voice_rate), s.rate, 0.5f..2f, 14,
                String.format(loc, "%.1f", s.rate)
            ) { v -> vm.update { it.copy(rate = v) } }
            LabeledSlider(
                stringResource(R.string.voice_pitch), s.pitch, 0.5f..2f, 14,
                String.format(loc, "%.1f", s.pitch)
            ) { v -> vm.update { it.copy(pitch = v) } }
            Text(
                stringResource(
                    when {
                        tts.initFailed -> R.string.voice_engine_failed
                        tts.enOffline -> R.string.voice_en_ready
                        else -> R.string.voice_en_missing
                    }
                ),
                color = if (tts.enOffline) lv.good else lv.bad, fontWeight = FontWeight.SemiBold
            )
            Text(
                stringResource(if (tts.bn) R.string.voice_bn_ready else R.string.voice_bn_missing),
                color = if (tts.bn) lv.good else lv.muted
            )
            ChunkyButton(stringResource(R.string.voice_test), { vm.testVoice(s) }, Modifier.fillMaxWidth())
        }

        // ---------- Reminders ----------
        Group(R.string.set_reminders) {
            ReminderRow(
                title = stringResource(R.string.rem_learning), on = s.learnOn, h = s.learnH, m = s.learnM, loc = loc,
                onToggle = { v ->
                    if (v) askNotifPermission()
                    vm.update { it.copy(learnOn = v) }
                },
                onPick = { pickTime(s.learnH, s.learnM) { h, m -> vm.update { it.copy(learnH = h, learnM = m) } } }
            )
            ReminderRow(
                title = stringResource(R.string.rem_quiz), on = s.quizOn, h = s.quizH, m = s.quizM, loc = loc,
                onToggle = { v ->
                    if (v) askNotifPermission()
                    vm.update { it.copy(quizOn = v) }
                },
                onPick = { pickTime(s.quizH, s.quizM) { h, m -> vm.update { it.copy(quizH = h, quizM = m) } } }
            )
            MutedText(stringResource(R.string.rem_battery_note))

            val notifOk = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
            val exactOk = remember(tick) { ReminderScheduler.canExact(ctx) }
            val battOk = remember(tick) {
                (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
            }
            Label(stringResource(R.string.rem_status))
            StatusLine(stringResource(R.string.rem_notif_perm), notifOk, stringResource(R.string.granted), stringResource(R.string.denied))
            StatusLine(stringResource(R.string.rem_exact_perm), exactOk, stringResource(R.string.granted), stringResource(R.string.denied))
            StatusLine(stringResource(R.string.rem_battery), battOk, stringResource(R.string.unrestricted), stringResource(R.string.optimized))
            if (!notifOk) {
                SecondaryButton(stringResource(R.string.open_notif_settings), {
                    openIntent(
                        ctx,
                        Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName)
                    )
                }, Modifier.fillMaxWidth())
            }
            if (!exactOk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                SecondaryButton(stringResource(R.string.open_exact_settings), {
                    openIntent(
                        ctx,
                        Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                    )
                }, Modifier.fillMaxWidth())
            }
            if (!battOk) {
                SecondaryButton(stringResource(R.string.open_battery_settings), {
                    openIntent(ctx, Intent(AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }, Modifier.fillMaxWidth())
            }
        }

        // ---------- Data ----------
        Group(R.string.set_data) {
            ChunkyButton(stringResource(R.string.export_btn), {
                exportLauncher.launch("learn-vocabulary-backup-${today()}.json")
            }, Modifier.fillMaxWidth())
            SecondaryButton(stringResource(R.string.import_btn), {
                importLauncher.launch(arrayOf("*/*"))
            }, Modifier.fillMaxWidth())
            ChunkyButton(
                stringResource(R.string.reset_btn), { showReset = true }, Modifier.fillMaxWidth(),
                color = lv.bad, textColor = androidx.compose.ui.graphics.Color.White
            )
        }

        // ---------- About / credits ----------
        Group(R.string.set_about) {
            Text(stringResource(R.string.about_version), color = lv.ink, fontWeight = FontWeight.SemiBold)
            MutedText(stringResource(R.string.credits_data))
            MutedText(stringResource(R.string.credits_fonts))
        }
        Spacer(Modifier.height(8.dp))
    }

    // ---------- dialogs ----------
    if (showCustom) {
        var text by remember { mutableStateOf(s.perDay.toString()) }
        val n = text.toIntOrNull()
        val valid = n != null && n in 1..500
        AlertDialog(
            onDismissRequest = { showCustom = false },
            containerColor = lv.card,
            title = { Text(stringResource(R.string.custom_title), color = lv.ink) },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter { c -> c.isDigit() }.take(3) },
                    singleLine = true, isError = !valid,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    supportingText = { Text(stringResource(R.string.custom_range)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = lv.accent, unfocusedBorderColor = lv.line,
                        focusedTextColor = lv.ink, unfocusedTextColor = lv.ink
                    )
                )
            },
            confirmButton = {
                TextButton(enabled = valid, onClick = {
                    vm.update { it.copy(perDay = n!!) }
                    showCustom = false
                }) { Text(stringResource(R.string.save), color = lv.accent) }
            },
            dismissButton = {
                TextButton(onClick = { showCustom = false }) { Text(stringResource(R.string.cancel), color = lv.muted) }
            }
        )
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            containerColor = lv.card,
            title = { Text(stringResource(R.string.reset_title), color = lv.ink) },
            text = { Text(stringResource(R.string.reset_text), color = lv.muted) },
            confirmButton = {
                TextButton(onClick = { showReset = false; vm.reset() }) {
                    Text(stringResource(R.string.reset_confirm), color = lv.bad)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) { Text(stringResource(R.string.cancel), color = lv.muted) }
            }
        )
    }
    val p = plan
    if (p != null) {
        AlertDialog(
            onDismissRequest = { vm.cancelImport() },
            containerColor = lv.card,
            title = { Text(stringResource(R.string.import_title), color = lv.ink) },
            text = {
                Text(
                    stringResource(
                        R.string.import_summary, p.data.learnedCount, p.data.days.size, p.data.userWords.size
                    ),
                    color = lv.muted
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.confirmImport() }) { Text(stringResource(R.string.import_confirm), color = lv.accent) }
            },
            dismissButton = {
                TextButton(onClick = { vm.cancelImport() }) { Text(stringResource(R.string.cancel), color = lv.muted) }
            }
        )
    }
}

@Composable
fun InstallVoiceDialog(main: MainViewModel) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = { main.tts.needInstall.value = false },
        containerColor = lv.card,
        title = { Text(stringResource(R.string.voice_install_title), color = lv.ink) },
        text = { Text(stringResource(R.string.voice_install_text), color = lv.muted) },
        confirmButton = {
            TextButton(onClick = {
                main.tts.needInstall.value = false
                openIntent(ctx, Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
            }) { Text(stringResource(R.string.voice_install_btn), color = lv.accent) }
        },
        dismissButton = {
            TextButton(onClick = { main.tts.needInstall.value = false }) {
                Text(stringResource(R.string.cancel), color = lv.muted)
            }
        }
    )
}

@Composable
private fun ReminderRow(
    title: String, on: Boolean, h: Int, m: Int, loc: Locale,
    onToggle: (Boolean) -> Unit, onPick: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Switch(
            checked = on, onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(checkedTrackColor = lv.accent, checkedThumbColor = lv.onAccent)
        )
        Text(title, color = lv.ink, modifier = Modifier.weight(1f))
        LVChip(String.format(loc, "%02d:%02d", h, m), on, onPick)
    }
}

@Composable
private fun StatusLine(label: String, ok: Boolean, yes: String, no: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = lv.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(if (ok) yes else no, color = if (ok) lv.good else lv.bad, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}
