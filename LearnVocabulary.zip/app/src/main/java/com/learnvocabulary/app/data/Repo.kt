package com.learnvocabulary.app.data

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import androidx.room.withTransaction
import androidx.sqlite.db.SimpleSQLiteQuery
import com.learnvocabulary.app.domain.QuizSetup
import com.learnvocabulary.app.domain.Slide
import com.learnvocabulary.app.domain.StatsCalc
import com.learnvocabulary.app.today
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.FilterInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.min

class CountingInputStream(s: InputStream) : FilterInputStream(s) {
    @Volatile var count: Long = 0
    override fun read(): Int {
        val r = super.read()
        if (r >= 0) count++
        return r
    }
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val r = super.read(b, off, len)
        if (r > 0) count += r
        return r
    }
}

data class LearnInfo(val slideNo: Int, val word: String, val meaning: String, val today: Int, val perDay: Int)

class Repo(private val app: Context, private val db: AppDatabase, val store: SettingsStore) {
    val dao: AppDao = db.dao()
    val settings: Flow<Settings> = store.flow

    val initProgress = MutableStateFlow(0f)
    val initDone = MutableStateFlow(false)
    val initError = MutableStateFlow<String?>(null)
    /** Set to true by Home/Word sheets so the Learn screen opens the active slide. */
    val openSlide = MutableStateFlow(false)

    // ---------- flows ----------
    val totalWords = dao.totalWords()
    val listCounts = dao.listCounts()
    val unlearnedByLevel = dao.unlearnedByLevel()
    val levelCounts = dao.levelCounts()
    val quizStats = dao.quizStats()
    val mostMissed = dao.mostMissed()
    val continueWords = dao.continueWords()
    val upNext = dao.upNext()
    val dayStats = dao.dayStats()
    val caught = dao.caught()
    val firstUse: Flow<String?> = dao.metaFlow("firstUse")
    val xp: Flow<Int> = dao.metaFlow("xp").map { it?.toIntOrNull() ?: 0 }
    val slides: Flow<Int> = dao.metaFlow("slides").map { it?.toIntOrNull() ?: 0 }
    val quizzes: Flow<Int> = dao.metaFlow("quizzes").map { it?.toIntOrNull() ?: 0 }

    fun wordFlow(id: Int): Flow<WordRow?> = dao.wordFlow(id)

    // ---------- init / import ----------
    suspend fun ensureInit() = withContext(Dispatchers.IO) {
        initError.value = null
        try {
            if (dao.meta("imported") != "1") importWords()
            for (k in listOf("xp", "slides", "quizzes")) dao.initMeta(MetaEntity(k, "0"))
            dao.initMeta(MetaEntity("firstUse", today().toString()))
            initDone.value = true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            initError.value = e.message ?: e.javaClass.simpleName
        }
    }

    private fun JsonReader.str(): String {
        if (peek() == JsonToken.NULL) { nextNull(); return "" }
        return nextString()
    }

    private fun JsonReader.dbl(): Double {
        if (peek() == JsonToken.NULL) { nextNull(); return 0.0 }
        return nextDouble()
    }

    private suspend fun importWords() {
        val raw = app.assets.open("words.json")
        val total = max(1, raw.available()).toFloat()
        val counting = CountingInputStream(raw)
        val batch = 500
        db.withTransaction {
            JsonReader(InputStreamReader(counting, Charsets.UTF_8)).use { r ->
                val bw = ArrayList<WordEntity>(batch)
                val bp = ArrayList<ProgressEntity>(batch)
                var pos = 0
                r.beginArray()
                while (r.hasNext()) {
                    r.beginObject()
                    var id = -1
                    var w = ""
                    var e = ""
                    var z = 0.0
                    val meanings = ArrayList<String>(3)
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "i" -> id = r.dbl().toInt()
                            "w" -> w = r.str()
                            "e" -> e = r.str()
                            "z" -> z = r.dbl()
                            "b" -> {
                                if (r.peek() == JsonToken.BEGIN_ARRAY) {
                                    r.beginArray()
                                    while (r.hasNext()) {
                                        val m = r.str().trim()
                                        if (m.isNotEmpty() && meanings.size < 3) meanings.add(m)
                                    }
                                    r.endArray()
                                } else r.skipValue()
                            }
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    pos++
                    if (w.isBlank() || meanings.isEmpty()) continue
                    if (id < 0) id = pos
                    bw.add(WordEntity(id, w.lowercase(), meanings.joinToString("|"), e.trim(), z, false))
                    bp.add(ProgressEntity(id))
                    if (bw.size >= batch) {
                        dao.insertWords(bw.toList())
                        dao.insertProgress(bp.toList())
                        bw.clear(); bp.clear()
                        initProgress.value = (counting.count / total).coerceIn(0f, 1f)
                    }
                }
                r.endArray()
                if (bw.isNotEmpty()) {
                    dao.insertWords(bw.toList())
                    dao.insertProgress(bp.toList())
                }
            }
            dao.setMeta(MetaEntity("imported", "1"))
        }
        initProgress.value = 1f
    }

    // ---------- word lists ----------
    private fun kindCond(kind: Int): String = when (kind) {
        in 0..3 -> "p.lvlOverride=$kind"
        10 -> "p.again=1"
        11 -> "p.later=1"
        12 -> "p.mistake=1"
        in 20..23 -> "p.learned=0 AND p.later=0 AND (${Q.LVL})=${kind - 20}"
        else -> "1=0"
    }

    suspend fun listWords(kind: Int, limit: Int = 200): List<WordRow> = withContext(Dispatchers.IO) {
        dao.rawWords(SimpleSQLiteQuery(Q.SEL + " WHERE " + kindCond(kind) + " ORDER BY w.z DESC LIMIT " + limit))
    }

    private suspend fun studyIds(kind: Int, n: Int): List<Int> {
        val extra = if (kind == 12) "" else " AND p.learned=0"
        val sql = "SELECT w.id FROM words w JOIN progress p ON p.wordId=w.id WHERE " + kindCond(kind) + extra +
            " ORDER BY p.again DESC, w.custom DESC, w.z DESC LIMIT " + n
        return dao.rawIds(SimpleSQLiteQuery(sql))
    }

    suspend fun studyCount(kind: Int): Int = withContext(Dispatchers.IO) {
        studyIds(kind, store.current().perDay).size
    }

    suspend fun search(q: String, bn: Boolean, filter: Int, limit: Int, offset: Int): List<WordRow> =
        withContext(Dispatchers.IO) {
            val sb = StringBuilder(Q.SEL + " WHERE 1=1")
            val args = ArrayList<Any>()
            when (filter) {
                in 1..4 -> sb.append(" AND p.lvlOverride=${filter - 1}")
                5 -> sb.append(" AND p.again=1")
                6 -> sb.append(" AND p.later=1")
                7 -> sb.append(" AND p.mistake=1")
                8 -> sb.append(" AND p.learned=1")
                9 -> sb.append(" AND w.custom=1")
            }
            val text = q.trim()
            var order = if (filter == 9) " ORDER BY w.id DESC" else " ORDER BY w.z DESC"
            if (text.isNotEmpty()) {
                val esc = text.lowercase().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
                if (!bn) {
                    sb.append(" AND w.w LIKE ? ESCAPE '\\'")
                    args.add("%$esc%")
                    order = " ORDER BY CASE WHEN w.w LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, w.z DESC"
                    args.add("$esc%")
                } else {
                    sb.append(" AND w.b LIKE ? ESCAPE '\\'")
                    args.add("%$esc%")
                }
            }
            sb.append(order).append(" LIMIT ").append(limit).append(" OFFSET ").append(offset)
            // Arg order: WHERE arg first, then ORDER BY arg (matches placeholder order in the SQL).
            dao.rawWords(SimpleSQLiteQuery(sb.toString(), args.toTypedArray()))
        }

    suspend fun setOverride(id: Int, lvl: Int) = withContext(Dispatchers.IO) { dao.setOverride(id, lvl) }
    suspend fun setLater(id: Int, v: Boolean) = withContext(Dispatchers.IO) { dao.setLater(id, v) }
    suspend fun markSeen(id: Int) = withContext(Dispatchers.IO) { dao.setSeen(id) }

    suspend fun addWord(word: String, meaningsCsv: String, example: String): Boolean = withContext(Dispatchers.IO) {
        val w = word.trim().lowercase()
        val ms = meaningsCsv.split(',', '\u060C', '\uFF0C').map { it.trim() }.filter { it.isNotEmpty() }
        if (w.isEmpty() || ms.isEmpty() || !w.all { it in 'a'..'z' }) return@withContext false
        db.withTransaction {
            val id = max(1_000_000, dao.maxCustomId() + 1)
            dao.insertWords(listOf(WordEntity(id, w, ms.joinToString("|"), example.trim(), 0.0, true)))
            dao.insertProgress(listOf(ProgressEntity(id)))
        }
        true
    }

    suspend fun deleteCustom(id: Int) = withContext(Dispatchers.IO) {
        db.withTransaction {
            dao.deleteProgress(id)
            dao.deleteCustomWord(id)
        }
    }

    // ---------- slide ----------
    suspend fun loadSlide(): Slide? = withContext(Dispatchers.IO) { Slide.parse(dao.meta("slide")) }

    suspend fun saveSlide(s: Slide?) = withContext(Dispatchers.IO) {
        dao.setMeta(MetaEntity("slide", s?.toJson() ?: ""))
    }

    private suspend fun createSlide(ids: List<Int>): Slide {
        val s = Slide(ids, ids.size, 0, ids.isEmpty())
        dao.setMeta(MetaEntity("slide", s.toJson()))
        return s
    }

    suspend fun newSlide(firstId: Int? = null): Slide = withContext(Dispatchers.IO) {
        val n = store.current().perDay
        val ids = ArrayList<Int>()
        if (firstId != null) {
            dao.clearLater(listOf(firstId))
            ids.add(firstId)
        }
        ids.addAll(dao.dailyIds(max(0, n - ids.size), firstId ?: -1))
        createSlide(ids)
    }

    suspend fun studyKind(kind: Int) = withContext(Dispatchers.IO) {
        val ids = studyIds(kind, store.current().perDay)
        if (kind == 11 && ids.isNotEmpty()) dao.clearLater(ids)
        createSlide(ids)
        openSlide.value = true
    }

    suspend fun learnNow(id: Int) {
        newSlide(id)
        openSlide.value = true
    }

    suspend fun continueToday() {
        val s = loadSlide()
        if (s == null || s.finished) newSlide(null)
        openSlide.value = true
    }

    private suspend fun todayLearned(): Int = StatsCalc.learned(dao.dayStat(today().toString()))

    /** Returns today's learned count after the update. */
    suspend fun markLearned(id: Int): Int = withContext(Dispatchers.IO) {
        db.withTransaction {
            val row = dao.word(id)
            val p = dao.progress(id)
            val day = today().toString()
            if (row != null && p != null && !p.learned) {
                dao.setLearned(id, day)
                dao.ensureDay(day)
                val l = row.lvl
                dao.addLearned(day, if (l == 0) 1 else 0, if (l == 1) 1 else 0, if (l == 2) 1 else 0, if (l == 3) 1 else 0)
                dao.addMeta("xp", 5)
            }
            todayLearned()
        }
    }

    suspend fun markAgain(id: Int) = withContext(Dispatchers.IO) { dao.setAgain(id) }
    suspend fun markLater(id: Int) = withContext(Dispatchers.IO) { dao.setLater(id, true) }

    suspend fun finishSlide(counted: Boolean) = withContext(Dispatchers.IO) {
        if (counted) dao.addMeta("slides", 1)
        catchUp()
    }

    suspend fun catchUp() = withContext(Dispatchers.IO) {
        val first = dao.meta("firstUse")?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        if (first != null) {
            val map = dao.dayStatsOnce().associateBy { it.day }
            val missed = StatsCalc.missedDays(first, today(), map)
            if (missed.isNotEmpty()) dao.addCaught(missed.map { CaughtEntity(it.toString()) })
        }
    }

    // ---------- quiz ----------
    suspend fun quizSetup(): QuizSetup = withContext(Dispatchers.IO) { QuizSetup.decode(dao.meta("quizSetup")) }

    suspend fun saveQuizSetup(s: QuizSetup) = withContext(Dispatchers.IO) {
        dao.setMeta(MetaEntity("quizSetup", s.encode()))
    }

    /** Returns (question pool, distractor pool). */
    suspend fun quizPools(setup: QuizSetup): Pair<List<WordRow>, List<WordRow>> = withContext(Dispatchers.IO) {
        val mine = setup.source == 1
        val sb = StringBuilder(Q.SEL + " WHERE 1=1")
        if (mine) sb.append(" AND w.custom=1")
        val d = setup.difficulty
        if (d in 1..4) sb.append(" AND (${Q.LVL})=${d - 1}")
        if (d == 5) sb.append(" AND p.mistake=1")
        else sb.append(" AND (p.seen=1 OR p.learned=1 OR w.custom=1)")
        val pool = ArrayList(dao.rawWords(SimpleSQLiteQuery(sb.toString())))
        if (!mine && d != 5 && pool.size < 12) {
            val have = pool.map { it.id }.toSet()
            val tb = StringBuilder(Q.SEL + " WHERE w.custom=0")
            if (d in 1..4) tb.append(" AND (${Q.LVL})=${d - 1}")
            tb.append(" ORDER BY w.z DESC LIMIT ").append(12 + have.size)
            for (w in dao.rawWords(SimpleSQLiteQuery(tb.toString()))) {
                if (pool.size >= 12) break
                if (w.id !in have) pool.add(w)
            }
        }
        val top = dao.rawWords(SimpleSQLiteQuery(Q.SEL + " WHERE w.custom=0 ORDER BY w.z DESC LIMIT 300"))
        pool.toList() to (pool + top).distinctBy { it.id }
    }

    suspend fun recordAnswer(wordId: Int, correct: Boolean) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val p = dao.progress(wordId) ?: ProgressEntity(wordId)
            val n = if (correct) {
                p.copy(box = min(5, p.box + 1), mistake = false, ok = p.ok + 1, lastOk = 1, seen = true)
            } else {
                p.copy(box = 0, bad = p.bad + 1, mistake = true, lastOk = 0, seen = true)
            }
            dao.upsertProgress(n)
            val day = today().toString()
            dao.ensureDay(day)
            dao.addQuiz(day, if (correct) 1 else 0, if (correct) 0 else 1)
        }
    }

    suspend fun addXp(n: Int) = withContext(Dispatchers.IO) { dao.addMeta("xp", n) }

    suspend fun finishQuiz(anyCorrect: Boolean) = withContext(Dispatchers.IO) {
        if (anyCorrect) dao.addMeta("quizzes", 1)
    }

    // ---------- notifications info ----------
    suspend fun learnInfo(): LearnInfo? = withContext(Dispatchers.IO) {
        val s = store.current()
        val slidesDone = dao.meta("slides")?.toIntOrNull() ?: 0
        val slide = Slide.parse(dao.meta("slide"))
        val headId = slide?.takeIf { !it.finished }?.queue?.firstOrNull()
        val id = headId ?: dao.dailyIds(1, -1).firstOrNull()
        val row = id?.let { dao.word(it) } ?: return@withContext null
        LearnInfo(slidesDone + 1, row.w, row.main, todayLearned(), s.perDay)
    }

    suspend fun quizNo(): Int = withContext(Dispatchers.IO) { (dao.meta("quizzes")?.toIntOrNull() ?: 0) + 1 }

    suspend fun quizPlayedToday(): Boolean = withContext(Dispatchers.IO) {
        StatsCalc.quizTotal(dao.dayStat(today().toString())) > 0
    }

    suspend fun goalDoneToday(): Boolean = withContext(Dispatchers.IO) {
        todayLearned() >= store.current().perDay
    }

    // ---------- backup / reset ----------
    suspend fun applyBackup(p: BackupData) = withContext(Dispatchers.IO) {
        db.withTransaction {
            dao.resetProgress()
            dao.deleteCustomProgress()
            dao.deleteCustomWords()
            dao.insertWords(p.userWords)
            dao.insertProgress(p.userWords.map { ProgressEntity(it.id) })
            val ids = dao.allIds().toHashSet()
            dao.upsertProgressList(p.progress.filter { it.wordId in ids })
            dao.clearDays()
            dao.upsertDays(p.days)
            dao.clearCaught()
            dao.addCaught(p.caught.map { CaughtEntity(it) })
            dao.setMeta(MetaEntity("firstUse", p.firstUse))
            dao.setMeta(MetaEntity("xp", p.xp.toString()))
            dao.setMeta(MetaEntity("slides", p.slides.toString()))
            dao.setMeta(MetaEntity("quizzes", p.quizzes.toString()))
            dao.setMeta(MetaEntity("quizSetup", p.quizSetup))
            dao.setMeta(MetaEntity("slide", p.slide))
        }
        store.update { p.settings }
    }

    suspend fun resetAll() = withContext(Dispatchers.IO) {
        db.withTransaction {
            dao.resetProgress()
            dao.deleteCustomProgress()
            dao.deleteCustomWords()
            dao.clearDays()
            dao.clearCaught()
            dao.setMeta(MetaEntity("firstUse", today().toString()))
            dao.setMeta(MetaEntity("xp", "0"))
            dao.setMeta(MetaEntity("slides", "0"))
            dao.setMeta(MetaEntity("quizzes", "0"))
            dao.deleteMeta("quizSetup")
            dao.deleteMeta("slide")
        }
        store.update { Settings(lang = it.lang) }
    }

    suspend fun exportData(): String = withContext(Dispatchers.IO) { BackupManager.toJson(this@Repo) }
}
