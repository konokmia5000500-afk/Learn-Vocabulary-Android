package com.learnvocabulary.app

import android.content.Context
import android.content.res.Configuration
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

/** Returns a context whose resources use the given app language (for toasts, notifications). */
fun Context.localized(lang: String): Context {
    val c = Configuration(resources.configuration)
    c.setLocale(Locale.forLanguageTag(lang))
    return createConfigurationContext(c)
}

fun today(): LocalDate = LocalDate.now()

fun fmtNum(v: Double, loc: Locale, maxDigits: Int = 1): String {
    val nf = NumberFormat.getInstance(loc)
    nf.maximumFractionDigits = maxDigits
    nf.minimumFractionDigits = 0
    return nf.format(v)
}
