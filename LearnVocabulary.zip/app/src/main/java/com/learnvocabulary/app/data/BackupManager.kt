package com.learnvocabulary.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class BackupData(
    val settings: Settings,
    val progress: List<ProgressEntity>,
    val userWords: List<WordEntity>,
    val days: List<DayStatEntity>,
    val caught: List<String>,
    val firstUse: String,
    val xp: Int,
    val slides: Int,
    val quizzes: Int,
    val quizSetup: String,
    val slide: String
) {
    val learnedCount: Int get() = progress.count { it.learned }
}

object BackupManager {
    const val SCHEMA = 1
    const val APP_VERSION = "0.1.0"

    suspend fun toJson(repo: Repo): String {
        val dao = repo.dao
        val s = repo.store.current()
        val o = JSONObject()
        o.put("schemaVersion", SCHEMA)
        o.put("appVersion", APP_VERSION)
        o.put("exportedAt", java.time.LocalDateTime.now().toString())
        o.put(
            "settings",
            JSONObject()
                .put("lang", s.lang).put("theme", s.theme).put("font", s.font)
                .put("textSize", s.textSize).put("perDay", s.perDay)
                .put("autoSpeak", s.autoSpeak).put("speakBn", s.speakBn)
                .put("accent", s.accent).put("rate", s.rate.toDouble()).put("pitch", s.pitch.toDouble())
                .put("learnOn", s.learnOn).put("learnH", s.learnH).put("learnM", s.learnM)
                .put("quizOn", s.quizOn).put("quizH", s.quizH).put("quizM", s.quizM)
        )
        val prog = JSONArray()
        for (p in dao.progressNonDefault()) {
            prog.put(
                JSONObject()
                    .put("id", p.wordId).put("learned", p.learned).put("learnedDay", p.learnedDay)
                    .put("again", p.again).put("later", p.later).put("mistake", p.mistake)
                    .put("lvl", p.lvlOverride).put("box", p.box).put("ok", p.ok).put("bad", p.bad)
                    .put("seen", p.seen).put("lastOk", p.lastOk)
            )
        }
        o.put("progress", prog)
        val uw = JSONArray()
        for (w in dao.customWordsOnce()) {
            uw.put(JSONObject().put("id", w.id).put("w", w.w).put("b", w.b).put("e", w.e))
        }
        o.put("userWords", uw)
        val days = JSONArray()
        for (d in dao.dayStatsOnce()) {
            days.put(
                JSONObject().put("d", d.day).put("l0", d.l0).put("l1", d.l1).put("l2", d.l2)
                    .put("l3", d.l3).put("qOk", d.qOk).put("qBad", d.qBad)
            )
        }
        o.put("days", days)
        o.put("caught", JSONArray(dao.caughtOnce()))
        o.put("firstUse", dao.meta("firstUse") ?: LocalDate.now().toString())
        o.put("xp", dao.meta("xp")?.toIntOrNull() ?: 0)
        o.put("slides", dao.meta("slides")?.toIntOrNull() ?: 0)
        o.put("quizzes", dao.meta("quizzes")?.toIntOrNull() ?: 0)
        o.put("quizSetup", dao.meta("quizSetup") ?: "")
        o.put("activeSlide", dao.meta("slide") ?: "")
        return o.toString()
    }

    /** Validates the whole structure and returns parsed data. Throws IllegalArgumentException when invalid. */
    fun parse(text: String): BackupData {
        try {
            val o = JSONObject(text)
            val v = o.getInt("schemaVersion")
            require(v in 1..SCHEMA) { "schema" }
            val so = o.getJSONObject("settings")
            val d = Settings()
            val settings = Settings(
                lang = so.optString("lang", d.lang).let { if (it == "bn") "bn" else "en" },
                theme = so.optString("theme", d.theme),
                font = so.optString("font", d.font),
                textSize = so.optInt("textSize", d.textSize).coerceIn(14, 24),
                perDay = so.optInt("perDay", d.perDay).coerceIn(1, 500),
                autoSpeak = so.optBoolean("autoSpeak", d.autoSpeak),
                speakBn = so.optBoolean("speakBn", d.speakBn),
                accent = so.optString("accent", d.accent),
                rate = so.optDouble("rate", d.rate.toDouble()).toFloat().coerceIn(0.3f, 3f),
                pitch = so.optDouble("pitch", d.pitch.toDouble()).toFloat().coerceIn(0.3f, 3f),
                learnOn = so.optBoolean("learnOn", d.learnOn),
                learnH = so.optInt("learnH", d.learnH).coerceIn(0, 23),
                learnM = so.optInt("learnM", d.learnM).coerceIn(0, 59),
                quizOn = so.optBoolean("quizOn", d.quizOn),
                quizH = so.optInt("quizH", d.quizH).coerceIn(0, 23),
                quizM = so.optInt("quizM", d.quizM).coerceIn(0, 59)
            )
            val pa = o.getJSONArray("progress")
            val progress = List(pa.length()) {
                val p = pa.getJSONObject(it)
                ProgressEntity(
                    wordId = p.getInt("id"),
                    learned = p.getBoolean("learned"),
                    learnedDay = p.optString("learnedDay", ""),
                    again = p.getBoolean("again"),
                    later = p.getBoolean("later"),
                    mistake = p.getBoolean("mistake"),
                    lvlOverride = p.getInt("lvl").coerceIn(-1, 3),
                    box = p.getInt("box").coerceIn(0, 5),
                    ok = p.getInt("ok").coerceAtLeast(0),
                    bad = p.getInt("bad").coerceAtLeast(0),
                    seen = p.getBoolean("seen"),
                    lastOk = p.getInt("lastOk").coerceIn(-1, 1)
                )
            }
            val ua = o.getJSONArray("userWords")
            val userWords = List(ua.length()) {
                val w = ua.getJSONObject(it)
                val id = w.getInt("id")
                require(id >= 1_000_000) { "user word id" }
                WordEntity(id, w.getString("w"), w.getString("b"), w.optString("e", ""), 0.0, true)
            }
            val da = o.getJSONArray("days")
            val days = List(da.length()) {
                val x = da.getJSONObject(it)
                val day = x.getString("d")
                LocalDate.parse(day)
                DayStatEntity(
                    day, x.getInt("l0"), x.getInt("l1"), x.getInt("l2"), x.getInt("l3"),
                    x.getInt("qOk"), x.getInt("qBad")
                )
            }
            val ca = o.getJSONArray("caught")
            val caught = List(ca.length()) {
                val day = ca.getString(it)
                LocalDate.parse(day)
                day
            }
            val first = o.getString("firstUse")
            LocalDate.parse(first)
            return BackupData(
                settings, progress, userWords, days, caught, first,
                o.optInt("xp", 0).coerceAtLeast(0), o.optInt("slides", 0).coerceAtLeast(0),
                o.optInt("quizzes", 0).coerceAtLeast(0),
                o.optString("quizSetup", ""), o.optString("activeSlide", "")
            )
        } catch (e: IllegalArgumentException) {
            throw e
        } catch (e: Exception) {
            throw IllegalArgumentException("invalid backup", e)
        }
    }
}
