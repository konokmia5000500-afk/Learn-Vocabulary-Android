package com.learnvocabulary.app.domain

import com.learnvocabulary.app.data.WordRow
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Question types: 0 MCQ en->bn, 1 MCQ bn->en, 2 fill blank, 3 type answer, 4 match pairs. */
data class Question(
    val type: Int,
    val wordId: Int,
    val en: String,
    val bn: String,
    /** MCQ/fill: the prompt shown; type: the Bengali meaning; match: unused */
    val prompt: String = "",
    val hint: String = "",
    val options: List<String> = emptyList(),
    val correct: Int = -1,
    val answerText: String = "",
    val pairIds: List<Int> = emptyList(),
    val pairEn: List<String> = emptyList(),
    val pairBn: List<String> = emptyList(),
    val leftOrder: List<Int> = emptyList(),
    val rightOrder: List<Int> = emptyList(),
    val repeat: Boolean = false
)

object QuizEngine {
    const val MAX_QUESTIONS = 24

    fun weight(w: WordRow): Double {
        var x = 1.0
        if (w.again) x += 3.0
        if (w.lvl >= 2) x += 2.0
        if (w.lvlOverride == 0) x -= 0.5
        x += max(0, 3 - w.box).toDouble()
        x += min(4, w.bad).toDouble()
        if (w.mistake) x += 3.0
        return x
    }

    /** Weighted sampling without replacement. */
    fun sample(pool: List<WordRow>, k: Int, rnd: Random, exclude: Set<Int> = emptySet()): List<WordRow> {
        return pool.filter { it.id !in exclude }
            .map { it to (-ln(max(rnd.nextDouble(), 1e-12)) / weight(it)) }
            .sortedBy { it.second }
            .take(k)
            .map { it.first }
    }

    fun build(setup: QuizSetup, pool: List<WordRow>, distract: List<WordRow>, rnd: Random = Random.Default): List<Question> {
        val n = min(setup.count, pool.size)
        if (n <= 0) return emptyList()
        val primary = sample(pool, n, rnd)
        val types = setup.types.toList().shuffled(rnd)
        val order = (0 until n).map { types[it % types.size] }.shuffled(rnd)
        val all = (pool + distract).distinctBy { it.id }
        val out = ArrayList<Question>()
        for (i in 0 until n) {
            val w = primary[i]
            var q: Question? = when (order[i]) {
                0 -> mcqEb(w, all, rnd)
                1 -> mcqBe(w, all, rnd)
                2 -> fill(w, all, rnd)
                3 -> typed(w)
                else -> match(w, all, rnd)
            }
            if (q == null) q = if (0 in setup.types) mcqEb(w, all, rnd) else null
            out.add(q ?: typed(w))
        }
        return out
    }

    private fun distractors(w: WordRow, all: List<WordRow>, rnd: Random, byMeaning: Boolean): List<WordRow> {
        val seen = HashSet<String>()
        seen.add(if (byMeaning) w.main else w.w)
        val res = ArrayList<WordRow>()
        for (d in all.shuffled(rnd)) {
            if (d.id == w.id || d.main.isBlank()) continue
            val key = if (byMeaning) d.main else d.w
            if (key in seen) continue
            seen.add(key)
            res.add(d)
            if (res.size == 3) break
        }
        return res
    }

    private fun mcqEb(w: WordRow, all: List<WordRow>, rnd: Random): Question? {
        if (w.main.isBlank()) return null
        val d = distractors(w, all, rnd, true)
        if (d.size < 3) return null
        val opts = (d.map { it.main } + w.main).shuffled(rnd)
        return Question(0, w.id, w.w, w.main, prompt = w.w, options = opts, correct = opts.indexOf(w.main), answerText = w.main)
    }

    private fun mcqBe(w: WordRow, all: List<WordRow>, rnd: Random): Question? {
        if (w.main.isBlank()) return null
        val d = distractors(w, all, rnd, false)
        if (d.size < 3) return null
        val opts = (d.map { it.w } + w.w).shuffled(rnd)
        return Question(1, w.id, w.w, w.main, prompt = w.main, options = opts, correct = opts.indexOf(w.w), answerText = w.w)
    }

    private fun fill(w: WordRow, all: List<WordRow>, rnd: Random): Question? {
        if (w.e.isBlank() || w.main.isBlank()) return null
        val re = Regex("\\b" + Regex.escape(w.w) + "\\b", RegexOption.IGNORE_CASE)
        if (!re.containsMatchIn(w.e)) return null
        val d = distractors(w, all, rnd, false)
        if (d.size < 3) return null
        val opts = (d.map { it.w } + w.w).shuffled(rnd)
        val sentence = re.replaceFirst(w.e, "_____")
        return Question(2, w.id, w.w, w.main, prompt = sentence, hint = w.main, options = opts, correct = opts.indexOf(w.w), answerText = w.w)
    }

    private fun typed(w: WordRow): Question =
        Question(3, w.id, w.w, w.main, prompt = w.main, answerText = w.w)

    private fun match(w: WordRow, all: List<WordRow>, rnd: Random): Question? {
        if (w.main.isBlank()) return null
        val mains = HashSet<String>()
        mains.add(w.main)
        val group = ArrayList<WordRow>()
        group.add(w)
        for (c in all.shuffled(rnd)) {
            if (c.id == w.id || c.main.isBlank() || c.main in mains) continue
            mains.add(c.main)
            group.add(c)
            if (group.size == 5) break
        }
        if (group.size < 5) return null
        val left = (0 until 5).toList().shuffled(rnd)
        val right = (0 until 5).toList().shuffled(rnd)
        return Question(
            4, w.id, w.w, w.main,
            pairIds = group.map { it.id }, pairEn = group.map { it.w }, pairBn = group.map { it.main },
            leftOrder = left, rightOrder = right
        )
    }

    fun repeatOf(q: Question): Question =
        Question(3, q.wordId, q.en, q.bn, prompt = q.bn, answerText = q.en, repeat = true)
}
