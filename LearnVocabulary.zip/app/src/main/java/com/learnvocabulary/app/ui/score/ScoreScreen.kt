package com.learnvocabulary.app.ui.score

import android.app.Application
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.DayStatEntity
import com.learnvocabulary.app.data.LvlCount
import com.learnvocabulary.app.data.QuizStats
import com.learnvocabulary.app.data.WordRow
import com.learnvocabulary.app.domain.StatsCalc
import com.learnvocabulary.app.fmtNum
import com.learnvocabulary.app.today
import com.learnvocabulary.app.ui.components.LVCard
import com.learnvocabulary.app.ui.components.LVChip
import com.learnvocabulary.app.ui.components.MutedText
import com.learnvocabulary.app.ui.components.SectionTitle
import com.learnvocabulary.app.ui.components.levelName
import com.learnvocabulary.app.ui.theme.LVColors
import com.learnvocabulary.app.ui.theme.headFont
import com.learnvocabulary.app.ui.theme.levelColor
import com.learnvocabulary.app.ui.theme.lv
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import kotlin.math.ceil
import kotlin.math.max

data class ScoreUi(
    val levels: List<LvlCount> = emptyList(),
    val quiz: QuizStats = QuizStats(0, 0, 0),
    val days: List<DayStatEntity> = emptyList(),
    val first: LocalDate? = null,
    val xp: Int = 0,
    val slides: Int = 0,
    val quizzes: Int = 0,
    val missedWords: List<WordRow> = emptyList(),
    val perDay: Int = 10
)

private data class Part1(
    val levels: List<LvlCount>, val quiz: QuizStats, val days: List<DayStatEntity>,
    val first: LocalDate?, val perDay: Int
)

class ScoreViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LearnApp).repo
    private val p1 = combine(repo.levelCounts, repo.quizStats, repo.dayStats, repo.firstUse, repo.settings) { l, q, d, f, s ->
        Part1(l, q, d, f?.let { runCatching { LocalDate.parse(it) }.getOrNull() }, s.perDay)
    }
    val ui: StateFlow<ScoreUi> = combine(p1, repo.xp, repo.slides, repo.quizzes, repo.mostMissed) { a, xp, sl, qz, mm ->
        ScoreUi(a.levels, a.quiz, a.days, a.first, xp, sl, qz, mm, a.perDay)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ScoreUi())
}

@Composable
fun ScoreScreen(vm: ScoreViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val loc = LocalConfiguration.current.locales[0]
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        StatisticsCard(ui)
        ActivityCard(ui, loc)
        LearningDaysCard(ui, loc)
        ProgressCard(ui)
        TilesGrid(ui)
        MostMissed(ui)
    }
}

// ---------------- Statistics rings ----------------
@Composable
private fun StatisticsCard(ui: ScoreUi) {
    val byLvl = (0..3).associateWith { l -> ui.levels.firstOrNull { it.lvl == l } }
    val totals = IntArray(4) { byLvl[it]?.total ?: 0 }
    val learned = IntArray(4) { byLvl[it]?.learned ?: 0 }
    val allTotal = totals.sum()
    val allLearned = learned.sum()
    val names = listOf(stringResource(R.string.ring_overall)) + (0..3).map { levelName(it) }
    val colors = listOf(lv.ink) + (0..3).map { levelColor(it, lv) }
    val tot = listOf(allTotal) + totals.toList()
    val lrn = listOf(allLearned) + learned.toList()
    val fracs = tot.indices.map { if (tot[it] == 0) 0f else lrn[it].toFloat() / tot[it] }

    LVCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.statistics), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Rings(fracs, colors)
        }
        Spacer(Modifier.height(10.dp))
        for (i in tot.indices) {
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(colors[i]))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(names[i], color = lv.ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    MutedText(stringResource(R.string.ring_detail, lrn[i], tot[i], max(0, tot[i] - lrn[i])))
                }
                Text("${(fracs[i] * 100).toInt()}%", color = lv.ink, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.quiz_on_learned), color = lv.ink, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniStat(stringResource(R.string.stat_correct), ui.quiz.ok, lv.good, Modifier.weight(1f))
            MiniStat(stringResource(R.string.stat_wrong), ui.quiz.bad, lv.bad, Modifier.weight(1f))
            MiniStat(stringResource(R.string.not_quizzed), ui.quiz.nq, lv.muted, Modifier.weight(1f))
        }
    }
}

@Composable
private fun MiniStat(label: String, v: Int, c: Color, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).border(1.dp, lv.line, RoundedCornerShape(12.dp)).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(v.toString(), color = c, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(label, color = lv.muted, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Rings(fracs: List<Float>, colors: List<Color>) {
    val anim = fracs.map { animateFloatAsState(it, tween(800), label = "ring").value }
    Canvas(Modifier.size(220.dp)) {
        val stroke = 16.dp.toPx()
        val gap = 5.dp.toPx()
        for (i in anim.indices) {
            val inset = stroke / 2f + i * (stroke + gap)
            val sz = Size(size.width - inset * 2, size.height - inset * 2)
            if (sz.width <= 0f) continue
            val tl = Offset(inset, inset)
            drawArc(colors[i].copy(alpha = 0.2f), -90f, 360f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (anim[i] > 0f) {
                drawArc(colors[i], -90f, 360f * anim[i].coerceAtMost(1f), false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
    }
}

// ---------------- Activity ----------------
@Composable
private fun ActivityCard(ui: ScoreUi, loc: java.util.Locale) {
    var quizMode by remember { mutableStateOf(false) }
    var month by remember { mutableStateOf(false) }
    val n = if (month) 30 else 7
    val td = today()
    val map = ui.days.associateBy { it.day }
    val range = (n - 1 downTo 0).map { td.minusDays(it.toLong()) }
    val data = range.map { map[it.toString()] }
    val total = data.sumOf { if (quizMode) StatsCalc.quizTotal(it) else StatsCalc.learned(it) }
    val sinceFirst = ui.first?.let { ChronoUnit.DAYS.between(it, td).toInt() + 1 } ?: 1
    val daysCount = max(1, minOf(n, sinceFirst))
    val avg = total.toDouble() / daysCount
    val okSum = data.sumOf { it?.qOk ?: 0 }
    val badSum = data.sumOf { it?.qBad ?: 0 }
    val acc = if (okSum + badSum == 0) 0 else (okSum * 100.0 / (okSum + badSum)).toInt()

    LVCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.activity), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LVChip(stringResource(R.string.mode_learned), !quizMode, { quizMode = false })
            LVChip(stringResource(R.string.mode_quiz), quizMode, { quizMode = true })
            Spacer(Modifier.weight(1f))
            LVChip(stringResource(R.string.range_week), !month, { month = false })
            LVChip(stringResource(R.string.range_month), month, { month = true })
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                MutedText(stringResource(R.string.daily_average))
                Text(fmtNum(avg, loc), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            }
            if (quizMode) {
                Text(stringResource(R.string.accuracy_pct, acc), color = lv.good, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(8.dp))
        val segs: List<List<Pair<Int, Color>>> = data.map { d ->
            if (quizMode) listOf((d?.qOk ?: 0) to lv.good, (d?.qBad ?: 0) to lv.bad)
            else listOf(
                (d?.l0 ?: 0) to levelColor(0, lv), (d?.l1 ?: 0) to levelColor(1, lv),
                (d?.l2 ?: 0) to levelColor(2, lv), (d?.l3 ?: 0) to levelColor(3, lv)
            )
        }
        BarChart(segs)
        Spacer(Modifier.height(4.dp))
        if (!month) {
            Row(Modifier.fillMaxWidth()) {
                range.forEach { d ->
                    Text(
                        d.dayOfWeek.getDisplayName(TextStyle.SHORT, loc).take(2),
                        Modifier.weight(1f), color = lv.muted, fontSize = 11.sp, textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MutedText(range.first().format(java.time.format.DateTimeFormatter.ofPattern("d MMM", loc)))
                MutedText(range.last().format(java.time.format.DateTimeFormatter.ofPattern("d MMM", loc)))
            }
        }
    }
}

@Composable
private fun BarChart(segs: List<List<Pair<Int, Color>>>) {
    val line = lv.line
    val maxV = max(1, segs.maxOfOrNull { s -> s.sumOf { it.first } } ?: 1)
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val n = segs.size
        val slot = size.width / n
        val bw = slot * 0.6f
        drawLine(line, Offset(0f, size.height), Offset(size.width, size.height), 2f)
        segs.forEachIndexed { i, s ->
            var y = size.height
            val x = i * slot + (slot - bw) / 2f
            for ((v, c) in s) {
                if (v <= 0) continue
                val h = size.height * v / maxV.toFloat() * 0.95f
                drawRect(c, Offset(x, y - h), Size(bw, h))
                y -= h
            }
        }
    }
}

// ---------------- Learning days ----------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LearningDaysCard(ui: ScoreUi, loc: java.util.Locale) {
    val td = today()
    val first = ui.first ?: td
    val map = ui.days.associateBy { it.day }
    val count = ChronoUnit.DAYS.between(first, td).toInt() + 1
    val allDays = remember(first, td) { (0 until count).map { first.plusDays(it.toLong()) } }
    val missedTotal = StatsCalc.missedDays(first, td, map).size
    val learnedTotal = ui.levels.sumOf { it.learned }
    val ls = rememberLazyListState(initialFirstVisibleItemIndex = (allDays.size - 1).coerceAtLeast(0))
    LVCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.learning_days), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        MutedText(stringResource(R.string.days_header, allDays.size, learnedTotal, missedTotal))
        Spacer(Modifier.height(8.dp))
        LazyRow(
            state = ls,
            flingBehavior = rememberSnapFlingBehavior(ls),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(allDays, key = { it.toString() }) { d ->
                val st = map[d.toString()]
                val n = StatsCalc.learned(st)
                val isToday = d == td
                val missed = !isToday && d.isAfter(first) && n == 0
                DayTile(d, n, st, isToday, missed, loc)
            }
        }
    }
}

@Composable
private fun DayTile(d: LocalDate, n: Int, st: DayStatEntity?, isToday: Boolean, missed: Boolean, loc: java.util.Locale) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier.width(112.dp).clip(shape)
            .background(if (isToday) lv.accent.copy(alpha = 0.10f) else lv.bg)
            .border(1.dp, if (isToday) lv.accent else lv.line, shape)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(d.dayOfWeek.getDisplayName(TextStyle.SHORT, loc), color = lv.muted, fontSize = 12.sp)
        Text(fmtNum(d.dayOfMonth.toDouble(), loc, 0), color = lv.ink, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text(d.month.getDisplayName(TextStyle.SHORT, loc), color = lv.muted, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        when {
            n > 0 -> Text(stringResource(R.string.n_learned, n), color = lv.good, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            missed -> Text(stringResource(R.string.missed), color = lv.bad, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            else -> Text(stringResource(R.string.n_learned, 0), color = lv.muted, fontSize = 13.sp)
        }
        if (isToday) Text(stringResource(R.string.today), color = lv.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        val qt = StatsCalc.quizTotal(st)
        if (qt > 0 && st != null) {
            Text(stringResource(R.string.quiz_rw, st.qOk, st.qBad), color = lv.ink, fontSize = 12.sp)
        } else {
            Text(stringResource(R.string.no_quiz), color = lv.muted, fontSize = 12.sp)
        }
    }
}

// ---------------- Progress ----------------
@Composable
private fun ProgressCard(ui: ScoreUi) {
    val total = ui.levels.sumOf { it.total }
    val learned = ui.levels.sumOf { it.learned }
    val res = LocalContext.current.resources
    val left = max(0, total - learned)
    val d = if (ui.perDay <= 0) 0 else ceil(left.toDouble() / ui.perDay).toInt()
    LVCard(Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.progress), color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { if (total == 0) 0f else learned.toFloat() / total },
            modifier = Modifier.fillMaxWidth().height(10.dp), color = lv.accent, trackColor = lv.line
        )
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.progress_learned, learned, total), color = lv.ink, fontSize = 15.sp)
        if (left > 0) {
            MutedText(res.getQuantityString(R.plurals.days_remain, d, ui.perDay, d))
        }
    }
}

@Composable
private fun TilesGrid(ui: ScoreUi) {
    val streak = StatsCalc.streak(ui.days.associateBy { it.day }, today())
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(stringResource(R.string.tile_streak), streak.toString(), Modifier.weight(1f))
            StatTile(stringResource(R.string.tile_xp), ui.xp.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(stringResource(R.string.tile_slides), ui.slides.toString(), Modifier.weight(1f))
            StatTile(stringResource(R.string.tile_quizzes), ui.quizzes.toString(), Modifier.weight(1f))
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    LVCard(modifier) {
        Text(value, color = lv.accent, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 30.sp)
        MutedText(label)
    }
}

@Composable
private fun MostMissed(ui: ScoreUi) {
    SectionTitle(stringResource(R.string.most_missed))
    LVCard(Modifier.fillMaxWidth()) {
        if (ui.missedWords.isEmpty()) {
            MutedText(stringResource(R.string.no_missed))
        } else {
            ui.missedWords.forEach { w ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(w.w, color = lv.ink, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        MutedText(w.main)
                    }
                    Text(stringResource(R.string.times_wrong, w.bad), color = lv.bad, fontSize = 13.sp)
                }
            }
        }
    }
}
