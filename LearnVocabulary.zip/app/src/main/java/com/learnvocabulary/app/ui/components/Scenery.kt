package com.learnvocabulary.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.learnvocabulary.app.ui.theme.lv

enum class SceneKind { Home, Learn, Score, Words, Quiz, Settings }

@Composable
fun Scenery(kind: SceneKind, modifier: Modifier = Modifier) {
    val a = lv.accent
    val g = lv.gold
    val bg = lv.bg
    Canvas(modifier) {
        when (kind) {
            SceneKind.Home -> home(a, g)
            SceneKind.Learn -> mountains(a, g)
            SceneKind.Score -> stairs(a, g)
            SceneKind.Words -> trees(a, g)
            SceneKind.Quiz -> night(g, bg)
            SceneKind.Settings -> clouds(a, g)
        }
    }
}

private fun DrawScope.home(a: Color, g: Color) {
    val w = size.width
    val h = size.height
    drawCircle(g.copy(alpha = 0.22f), radius = w * 0.09f, center = Offset(w * 0.78f, h * 0.66f))
    val p1 = Path().apply {
        moveTo(0f, h * 0.86f)
        quadraticBezierTo(w * 0.25f, h * 0.68f, w * 0.55f, h * 0.86f)
        quadraticBezierTo(w * 0.8f, h * 0.74f, w, h * 0.84f)
        lineTo(w, h); lineTo(0f, h); close()
    }
    drawPath(p1, a.copy(alpha = 0.10f))
    val p2 = Path().apply {
        moveTo(0f, h * 0.93f)
        quadraticBezierTo(w * 0.35f, h * 0.82f, w * 0.7f, h * 0.94f)
        quadraticBezierTo(w * 0.9f, h * 0.88f, w, h * 0.92f)
        lineTo(w, h); lineTo(0f, h); close()
    }
    drawPath(p2, g.copy(alpha = 0.14f))
}

private fun DrawScope.mountains(a: Color, g: Color) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(0f, h)
        lineTo(w * 0.2f, h * 0.7f); lineTo(w * 0.35f, h * 0.82f); lineTo(w * 0.55f, h * 0.6f)
        lineTo(w * 0.78f, h * 0.85f); lineTo(w * 0.9f, h * 0.75f); lineTo(w, h * 0.9f)
        lineTo(w, h); close()
    }
    drawPath(p, a.copy(alpha = 0.10f))
    val q = Path().apply {
        moveTo(0f, h); lineTo(w * 0.1f, h * 0.88f); lineTo(w * 0.3f, h * 0.95f)
        lineTo(w * 0.6f, h * 0.84f); lineTo(w * 0.85f, h * 0.96f); lineTo(w, h * 0.9f); lineTo(w, h); close()
    }
    drawPath(q, g.copy(alpha = 0.14f))
}

private fun DrawScope.stairs(a: Color, g: Color) {
    val w = size.width
    val h = size.height
    for (i in 0..5) {
        val sw = w * 0.11f
        val hh = h * (0.06f + i * 0.05f)
        drawRect(
            (if (i % 2 == 0) a else g).copy(alpha = 0.12f),
            topLeft = Offset(w * 0.34f + i * sw, h - hh),
            size = Size(sw + 1f, hh)
        )
    }
}

private fun DrawScope.trees(a: Color, g: Color) {
    val w = size.width
    val h = size.height
    val xs = listOf(0.08f, 0.3f, 0.56f, 0.8f, 0.97f)
    xs.forEachIndexed { i, fx ->
        val cx = w * fx
        val base = h * (0.94f - (i % 2) * 0.03f)
        val r = w * (0.07f + (i % 3) * 0.015f)
        drawRect(g.copy(alpha = 0.16f), topLeft = Offset(cx - r * 0.12f, base - r * 1.2f), size = Size(r * 0.24f, r * 1.2f))
        drawCircle(a.copy(alpha = 0.11f), radius = r, center = Offset(cx, base - r * 1.6f))
        drawCircle(a.copy(alpha = 0.11f), radius = r * 0.75f, center = Offset(cx - r * 0.6f, base - r * 1.2f))
        drawCircle(a.copy(alpha = 0.11f), radius = r * 0.75f, center = Offset(cx + r * 0.6f, base - r * 1.2f))
    }
}

private fun DrawScope.night(g: Color, bg: Color) {
    val w = size.width
    val h = size.height
    val stars = listOf(
        0.1f to 0.08f, 0.25f to 0.18f, 0.4f to 0.06f, 0.55f to 0.22f, 0.7f to 0.1f, 0.88f to 0.2f,
        0.15f to 0.32f, 0.35f to 0.38f, 0.6f to 0.42f, 0.82f to 0.36f, 0.95f to 0.05f, 0.05f to 0.5f
    )
    stars.forEachIndexed { i, (fx, fy) ->
        drawCircle(g.copy(alpha = 0.30f), radius = w * (0.006f + (i % 3) * 0.003f), center = Offset(w * fx, h * fy))
    }
    drawCircle(g.copy(alpha = 0.28f), radius = w * 0.07f, center = Offset(w * 0.8f, h * 0.12f))
    drawCircle(bg, radius = w * 0.06f, center = Offset(w * 0.83f, h * 0.105f))
}

private fun DrawScope.cloud(cx: Float, cy: Float, s: Float, c: Color) {
    drawCircle(c, s * 0.5f, Offset(cx, cy))
    drawCircle(c, s * 0.7f, Offset(cx + s * 0.7f, cy - s * 0.2f))
    drawCircle(c, s * 0.5f, Offset(cx + s * 1.4f, cy))
    drawRect(c, topLeft = Offset(cx, cy), size = Size(s * 1.4f, s * 0.5f))
}

private fun DrawScope.clouds(a: Color, g: Color) {
    val w = size.width
    val h = size.height
    cloud(w * 0.08f, h * 0.12f, w * 0.1f, a.copy(alpha = 0.09f))
    cloud(w * 0.55f, h * 0.2f, w * 0.13f, g.copy(alpha = 0.12f))
    cloud(w * 0.25f, h * 0.38f, w * 0.08f, g.copy(alpha = 0.10f))
    cloud(w * 0.7f, h * 0.55f, w * 0.1f, a.copy(alpha = 0.08f))
}
