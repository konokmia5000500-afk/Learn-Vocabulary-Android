package com.learnvocabulary.app.tts

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.learnvocabulary.app.data.Settings
import kotlinx.coroutines.flow.MutableStateFlow

data class TtsStatus(
    val initFailed: Boolean = false,
    val ready: Boolean = false,
    val enOffline: Boolean = false,
    val bn: Boolean = false
)

/** Singleton wrapper around Android TextToSpeech (speech output only, no microphone). */
class TtsManager(private val app: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pendingBn: String? = null
    private var pendingSpeak: (() -> Unit)? = null
    private var accent = "us"

    val status = MutableStateFlow(TtsStatus())
    val needInstall = MutableStateFlow(false)

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onError(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) {
            if (utteranceId == "en") {
                val b = pendingBn
                pendingBn = null
                if (b != null) main.post { speakBengali(b) }
            }
        }
    }

    fun init() {
        if (tts != null) return
        try {
            tts = TextToSpeech(app) { st ->
                main.post {
                    if (st == TextToSpeech.SUCCESS) {
                        ready = true
                        tts?.setOnUtteranceProgressListener(listener)
                        refresh(accent)
                        pendingSpeak?.invoke()
                        pendingSpeak = null
                    } else {
                        ready = false
                        status.value = TtsStatus(initFailed = true)
                    }
                }
            }
        } catch (e: Exception) {
            status.value = TtsStatus(initFailed = true)
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        ready = false
        pendingSpeak = null
        status.value = TtsStatus()
    }

    fun stop() {
        pendingBn = null
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }

    private fun featuresOf(v: Voice): Set<String> = v.features ?: emptySet()

    private fun englishVoices(): List<Voice> {
        val t = tts ?: return emptyList()
        val all = try { t.voices } catch (e: Exception) { null } ?: return emptyList()
        return all.filter {
            it.locale.language == "en" &&
                !it.isNetworkConnectionRequired &&
                !featuresOf(it).contains(TextToSpeech.Engine.KEY_FEATURE_NETWORK_SYNTHESIS) &&
                !featuresOf(it).contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
    }

    private fun pickEnglish(acc: String): Voice? {
        val offline = englishVoices()
        if (offline.isEmpty()) return null
        val country = if (acc == "uk") "GB" else "US"
        return offline.filter { it.locale.country.equals(country, true) }.maxByOrNull { it.quality }
            ?: offline.maxByOrNull { it.quality }
    }

    private fun pickBengali(): Voice? {
        val t = tts ?: return null
        val all = try { t.voices } catch (e: Exception) { null } ?: return null
        return all.filter {
            it.locale.language == "bn" && !featuresOf(it).contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }.sortedBy { if (it.isNetworkConnectionRequired) 1 else 0 }.firstOrNull()
    }

    /** Re-checks which voices are installed. */
    fun refresh(acc: String) {
        accent = acc
        if (!ready) return
        status.value = TtsStatus(
            initFailed = false,
            ready = true,
            enOffline = pickEnglish(acc) != null,
            bn = pickBengali() != null
        )
    }

    /** Speaks the English word; optionally the Bengali meaning afterwards (if enabled in settings). */
    fun speak(word: String, bn: String?, s: Settings) {
        if (tts == null) {
            pendingSpeak = { speak(word, bn, s) }
            init()
            return
        }
        if (!ready) {
            pendingSpeak = { speak(word, bn, s) }
            return
        }
        accent = s.accent
        val voice = pickEnglish(s.accent)
        if (voice == null) {
            needInstall.value = true
            refresh(s.accent)
            return
        }
        try {
            val t = tts ?: return
            t.stop()
            t.setVoice(voice)
            t.setSpeechRate(s.rate)
            t.setPitch(s.pitch)
            pendingBn = if (s.speakBn && !bn.isNullOrBlank()) bn else null
            t.speak(word, TextToSpeech.QUEUE_FLUSH, null, "en")
        } catch (e: Exception) {
            status.value = status.value.copy(initFailed = true)
        }
    }

    private fun speakBengali(text: String) {
        val t = tts ?: return
        val v = pickBengali() ?: return
        try {
            t.setVoice(v)
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bn")
        } catch (_: Exception) {
        }
    }
}
