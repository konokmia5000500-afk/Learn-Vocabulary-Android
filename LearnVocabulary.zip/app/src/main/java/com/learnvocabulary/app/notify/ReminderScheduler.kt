package com.learnvocabulary.app.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.learnvocabulary.app.data.Settings
import java.util.Calendar

object ReminderScheduler {
    const val ACTION = "com.learnvocabulary.app.REMINDER"
    const val EXTRA_KIND = "kind"
    const val KIND_LEARN = 0
    const val KIND_QUIZ = 1

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    private fun pending(ctx: Context, kind: Int): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION).putExtra(EXTRA_KIND, kind)
        return PendingIntent.getBroadcast(
            ctx, 200 + kind, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun nextTrigger(hour: Int, minute: Int): Long {
        val now = System.currentTimeMillis()
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        // strictly in the future (with a 60 s margin so a just-fired alarm moves to tomorrow)
        while (c.timeInMillis <= now + 60_000L) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun schedule(ctx: Context, kind: Int, hour: Int, minute: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = nextTrigger(hour, minute)
        val pi = pending(ctx, kind)
        try {
            if (canExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, kind: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, kind))
    }

    fun syncAll(ctx: Context, s: Settings) {
        if (s.learnOn) schedule(ctx, KIND_LEARN, s.learnH, s.learnM) else cancel(ctx, KIND_LEARN)
        if (s.quizOn) schedule(ctx, KIND_QUIZ, s.quizH, s.quizM) else cancel(ctx, KIND_QUIZ)
    }
}
