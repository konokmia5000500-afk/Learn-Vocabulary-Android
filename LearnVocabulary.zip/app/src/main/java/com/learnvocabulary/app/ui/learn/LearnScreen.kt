package com.learnvocabulary.app.ui.learn

import android.app.Application
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.R
import com.learnvocabulary.app.data.WordRow
import com.learnvocabulary.app.domain.Slide
import com.learnvocabulary.app.domain.StatsCalc
import com.learnvocabulary.app.localized
import com.learnvocabulary.app.today
import com.learnvocabulary.app.ui.LVIcons
import com.learnvocabulary.app.ui.MainViewModel
import com.learnvocabulary.app.ui.components.ChunkyButton
import com.learnvocabulary.app.ui.components.CountTile
import com.learnvocabulary.app.ui.components.LVCard
import com.learnvocabulary.app.ui.components.LVChip
import com.learnvocabulary.app.ui.components.LevelChips
import com.learnvocabulary.app.ui.components.SectionTitle
import com.learnvocabulary.app.ui.components.SecondaryButton
import com.learnvocabulary.app.ui.components.SpeakerButton
import com.learnvocabulary.app.ui.components.Sheets
import com.learnvocabulary.app.ui.components.highlighted
import com.learnvocabulary.app.ui.components.levelName
import com.learnvocabulary.app.ui.components.rememberSheetState
import com.learnvocabulary.app.ui.theme.headFont
import com.learnvocabulary.app.ui.theme.levelColor
import com.learnvocabulary.app.ui.theme.lv
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.min

data class LearnStart(
    val perDay: Int = 10,
    val today: Int = 0,
    val unl: List<Int> = listOf(0, 0, 0, 0),
    val again: Int = 0,
    val later: Int = 0,
    val mistake: Int = 0
)

class LearnViewModel(private val app: Application) : AndroidViewModel(app) {
    private val repo = (app as LearnApp).repo

    val slide = MutableStateFlow<Slide?>(null)
    val inSlide = MutableStateFlow(false)
    val loaded = MutableStateFlow(false)

    @OptIn(ExperimentalCoroutinesApi::class)
    val current: StateFlow<WordRow?> = slide
        .map { it?.queue?.firstOrNull() }
        .distinctUntilChanged()
        .flatMapLatest { id -> if (id == null) flowOf<WordRow?>(null) else repo.wordFlow(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val start: StateFlow<LearnStart> = combine(
        repo.settings, repo.dayStats, repo.unlearnedByLevel, repo.listCounts
    ) { s, days, unl, lc ->
        val arr = IntArray(4)
        unl.forEach { if (it.lvl in 0..3) arr[it.lvl] = it.c }
        LearnStart(
            s.perDay, StatsCalc.learned(days.firstOrNull { it.day == today().toString() }),
            arr.toList(), lc.again, lc.later, lc.mistake
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LearnStart())

    init {
        viewModelScope.launch {
            repo.openSlide.collect { open ->
                if (open) {
                    slide.value = repo.loadSlide()
                    inSlide.value = slide.value != null
                    loaded.value = true
                    repo.openSlide.value = false
                }
            }
        }
        reload()
    }

    fun reload() {
        viewModelScope.launch {
            slide.value = repo.loadSlide()
            if (!loaded.value) {
                inSlide.value = slide.value?.finished == false
                loaded.value = true
            }
        }
    }

    fun markSeen(id: Int) {
        viewModelScope.launch { repo.markSeen(id) }
    }

    fun startNew() {
        viewModelScope.launch {
            slide.value = repo.newSlide(null)
            inSlide.value = true
        }
    }

    fun closeSlide() {
        inSlide.value = false
    }

    fun openSlideAgain() {
        if (slide.value != null) inSlide.value = true
    }

    fun back() {
        viewModelScope.launch {
            repo.saveSlide(null)
            slide.value = null
            inSlide.value = false
        }
    }

    private suspend fun finishIfEmpty(ns: Slide): Slide {
        if (ns.queue.isNotEmpty()) return ns
        val f = ns.copy(finished = true)
        repo.finishSlide(counted = f.total > 0)
        return f
    }

    fun onLearned() {
        viewModelScope.launch {
            val s = slide.value ?: return@launch
            val id = s.queue.firstOrNull() ?: return@launch
            val count = repo.markLearned(id)
            val goal = repo.store.current().perDay
            var ns = s.copy(queue = s.queue.drop(1), done = s.done + 1)
            if (count >= goal) repo.catchUp()
            if (count == goal) {
                val lang = repo.store.current().lang
                Toast.makeText(app.localized(lang), R.string.goal_reached, Toast.LENGTH_SHORT).show()
            }
            ns = finishIfEmpty(ns)
            repo.saveSlide(ns)
            slide.value = ns
        }
    }

    fun onAgain() {
        viewModelScope.launch {
            val s = slide.value ?: return@launch
            val id = s.queue.firstOrNull() ?: return@launch
            repo.markAgain(id)
            val rest = s.queue.drop(1).toMutableList()
            rest.add(min(3, rest.size), id)
            val ns = s.copy(queue = rest)
            repo.saveSlide(ns)
            slide.value = ns
        }
    }

    fun onLater() {
        viewModelScope.launch {
            val s = slide.value ?: return@launch
            val id = s.queue.firstOrNull() ?: return@launch
            repo.markLater(id)
            var ns = s.copy(queue = s.queue.drop(1), total = maxOf(0, s.total - 1))
            ns = finishIfEmpty(ns)
            repo.saveSlide(ns)
            slide.value = ns
        }
    }
}

@Composable
fun LearnScreen(main: MainViewModel, navigate: (String) -> Unit, vm: LearnViewModel = viewModel()) {
    val slide by vm.slide.collectAsStateWithLifecycle()
    val inSlide by vm.inSlide.collectAsStateWithLifecycle()
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    val sheets = rememberSheetState()

    LaunchedEffect(Unit) { vm.reload() }
    DisposableEffect(Unit) { onDispose { main.stopSpeak() } }

    if (!loaded) return
    val s = slide
    when {
        inSlide && s != null && s.finished -> CompleteView(vm)
        inSlide && s != null -> SlideView(vm, main)
        else -> StartView(vm, sheets, s)
    }
    Sheets(sheets, main) { vm.reload() }
}

@Composable
private fun StartView(vm: LearnViewModel, sheets: com.learnvocabulary.app.ui.components.SheetState, slide: Slide?) {
    val st by vm.start.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LVCard(Modifier.fillMaxWidth()) {
            val goalDone = st.today >= st.perDay
            Text(
                stringResource(if (goalDone) R.string.goal_complete else R.string.todays_goal),
                color = lv.ink, fontFamily = headFont, fontWeight = FontWeight.Bold, fontSize = 20.sp
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (goalDone) stringResource(R.string.goal_complete_text, st.today)
                else stringResource(R.string.todays_words, st.today, st.perDay),
                color = if (goalDone) lv.good else lv.muted, fontSize = 15.sp
            )
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (st.today.toFloat() / st.perDay.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = if (goalDone) lv.good else lv.accent, trackColor = lv.line
            )
        }
        if (slide != null && !slide.finished) {
            SecondaryButton(
                stringResource(R.string.resume_slide, slide.done, slide.total),
                { vm.openSlideAgain() }, Modifier.fillMaxWidth()
            )
        }
        ChunkyButton(
            stringResource(R.string.start_slide, st.perDay),
            { vm.startNew() }, Modifier.fillMaxWidth()
        )
        SectionTitle(stringResource(R.string.learn_by_type))
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CountTile(levelName(0), st.unl[0], { sheets.listKind = 20 }, levelColor(0, lv), Modifier.weight(1f))
                CountTile(levelName(1), st.unl[1], { sheets.listKind = 21 }, levelColor(1, lv), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CountTile(levelName(2), st.unl[2], { sheets.listKind = 22 }, levelColor(2, lv), Modifier.weight(1f))
                CountTile(levelName(3), st.unl[3], { sheets.listKind = 23 }, levelColor(3, lv), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CountTile(stringResource(R.string.list_mistakes), st.mistake, { sheets.listKind = 12 }, lv.accent, Modifier.weight(1f))
                CountTile(stringResource(R.string.list_later), st.later, { sheets.listKind = 11 }, lv.accent, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CountTile(stringResource(R.string.list_again), st.again, { sheets.listKind = 10 }, lv.accent, Modifier.weight(1f))
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CompleteView(vm: LearnViewModel) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LVCard(Modifier.fillMaxWidth()) {
            Icon(LVIcons.Check, null, tint = lv.good, modifier = Modifier.size(48.dp).align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.slide_complete), color = lv.ink, fontFamily = headFont,
                fontWeight = FontWeight.Bold, fontSize = 26.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(20.dp))
            ChunkyButton(stringResource(R.string.new_slide), { vm.startNew() }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            SecondaryButton(stringResource(R.string.back), { vm.back() }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SlideView(vm: LearnViewModel, main: MainViewModel) {
    val slide by vm.slide.collectAsStateWithLifecycle()
    val row by vm.current.collectAsStateWithLifecycle()
    val s = slide ?: return
    val r = row

    LaunchedEffect(r?.id) {
        val w = r ?: return@LaunchedEffect
        vm.markSeen(w.id)
        if (main.settings.value?.autoSpeak == true) main.speak(w, true)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
                progress = { if (s.total == 0) 1f else (s.done.toFloat() / s.total).coerceIn(0f, 1f) },
                modifier = Modifier.weight(1f).height(10.dp),
                color = lv.accent, trackColor = lv.line
            )
            Text(
                "${s.done}/${s.total}", color = lv.muted, fontSize = 14.sp,
                modifier = Modifier.padding(start = 10.dp)
            )
            IconButton(onClick = { vm.closeSlide() }) {
                Icon(LVIcons.Close, stringResource(R.string.cd_close), tint = lv.ink)
            }
        }
        if (r == null) return@Column
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LVChip(levelName(r.lvl), true, null, color = levelColor(r.lvl, lv))
            if (r.again) LVChip(stringResource(R.string.chip_review), true, null, color = lv.gold)
            if (r.mistake) LVChip(stringResource(R.string.chip_mistake), true, null, color = lv.bad)
        }
        LVCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    r.w, color = lv.ink, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold,
                    fontSize = 38.sp, modifier = Modifier.weight(1f)
                )
                SpeakerButton({ main.speak(r, true) })
            }
            Spacer(Modifier.height(8.dp))
            r.meanings.forEachIndexed { i, m ->
                Text(
                    m,
                    color = if (i == 0) lv.accent else lv.muted,
                    fontSize = if (i == 0) 28.sp else 18.sp,
                    fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Normal
                )
            }
            if (r.e.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    highlighted(r.e, r.w, lv.accent),
                    color = lv.ink, fontStyle = FontStyle.Italic, fontSize = 17.sp
                )
            }
        }
        LevelChips(r.lvlOverride) { l -> main.setOverride(r.id, if (r.lvlOverride == l) -1 else l) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            ChunkyButton(
                stringResource(R.string.learn_again), { vm.onAgain() }, Modifier.weight(1f),
                color = lv.gold, textColor = androidx.compose.ui.graphics.Color.White
            )
            ChunkyButton(
                stringResource(R.string.learned), { vm.onLearned() }, Modifier.weight(1f),
                color = lv.good, textColor = androidx.compose.ui.graphics.Color.White
            )
        }
        SecondaryButton(stringResource(R.string.learn_later), { vm.onLater() }, Modifier.fillMaxWidth())
    }
}
