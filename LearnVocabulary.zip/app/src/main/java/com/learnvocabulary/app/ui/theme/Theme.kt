package com.learnvocabulary.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.core.view.WindowCompat
import com.learnvocabulary.app.data.Settings

data class LVColors(
    val bg: Color,
    val card: Color,
    val ink: Color,
    val muted: Color,
    val accent: Color,
    val onAccent: Color,
    val gold: Color,
    val line: Color,
    val good: Color,
    val bad: Color,
    val dark: Boolean
)

val LightPalette = LVColors(
    bg = Color(0xFFF7F0E1), card = Color(0xFFFFFAF0), ink = Color(0xFF2C2118), muted = Color(0xFF7A6A55),
    accent = Color(0xFF8A2B2B), onAccent = Color.White, gold = Color(0xFFB8892B), line = Color(0xFFE0D2B4),
    good = Color(0xFF2F7D4F), bad = Color(0xFFB3362F), dark = false
)
val DarkPalette = LVColors(
    bg = Color(0xFF14110D), card = Color(0xFF221C15), ink = Color(0xFFF0E6D2), muted = Color(0xFFA89A82),
    accent = Color(0xFFE0A458), onAccent = Color(0xFF14110D), gold = Color(0xFFD2A24C), line = Color(0xFF3A3024),
    good = Color(0xFF5FBF84), bad = Color(0xFFE0685F), dark = true
)
val SepiaPalette = LVColors(
    bg = Color(0xFFE8D8B4), card = Color(0xFFF2E6C8), ink = Color(0xFF2C2118), muted = Color(0xFF6B5B43),
    accent = Color(0xFF7A3B14), onAccent = Color.White, gold = Color(0xFFA67B24), line = Color(0xFFCDBB92),
    good = Color(0xFF2F7D4F), bad = Color(0xFFB3362F), dark = false
)
val ForestPalette = LVColors(
    bg = Color(0xFF17261F), card = Color(0xFF223A2E), ink = Color(0xFFEAF1E4), muted = Color(0xFFA3B8A8),
    accent = Color(0xFFE3C26A), onAccent = Color(0xFF17261F), gold = Color(0xFFD9B25A), line = Color(0xFF35523F),
    good = Color(0xFF6BCB8B), bad = Color(0xFFE8756B), dark = true
)

val LocalLV = staticCompositionLocalOf { LightPalette }
val LocalHeadFont = staticCompositionLocalOf<FontFamily> { FontFamily.Serif }

val lv: LVColors
    @Composable @ReadOnlyComposable get() = LocalLV.current

val headFont: FontFamily
    @Composable @ReadOnlyComposable get() = LocalHeadFont.current

fun levelColor(l: Int, p: LVColors): Color = when (l) {
    0 -> p.good
    1 -> p.gold
    2 -> p.accent
    else -> p.bad
}

fun Color.darken(f: Float = 0.76f): Color = Color(red * f, green * f, blue * f, alpha)

private fun buildTypography(body: FontFamily, head: FontFamily, scale: Float): Typography {
    val b = Typography()
    fun TextStyle.s(f: FontFamily) = copy(
        fontFamily = f,
        fontSize = fontSize * scale,
        lineHeight = lineHeight * scale
    )
    return Typography(
        displayLarge = b.displayLarge.s(head), displayMedium = b.displayMedium.s(head),
        displaySmall = b.displaySmall.s(head),
        headlineLarge = b.headlineLarge.s(head), headlineMedium = b.headlineMedium.s(head),
        headlineSmall = b.headlineSmall.s(head),
        titleLarge = b.titleLarge.s(head), titleMedium = b.titleMedium.s(head), titleSmall = b.titleSmall.s(body),
        bodyLarge = b.bodyLarge.s(body), bodyMedium = b.bodyMedium.s(body), bodySmall = b.bodySmall.s(body),
        labelLarge = b.labelLarge.s(body), labelMedium = b.labelMedium.s(body), labelSmall = b.labelSmall.s(body)
    )
}

@Composable
fun LearnTheme(s: Settings, content: @Composable () -> Unit) {
    val sysDark = isSystemInDarkTheme()
    val pal = when (s.theme) {
        "light" -> LightPalette
        "dark" -> DarkPalette
        "sepia" -> SepiaPalette
        "forest" -> ForestPalette
        else -> if (sysDark) DarkPalette else LightPalette
    }
    val head = when (s.font) {
        "sans" -> FontFamily.SansSerif
        else -> FontFamily.Serif
    }
    val body = when (s.font) {
        "serif" -> FontFamily.Serif
        else -> FontFamily.SansSerif
    }
    val typo = buildTypography(body, head, s.textSize / 16f)
    val scheme = if (pal.dark) {
        darkColorScheme(
            primary = pal.accent, onPrimary = pal.onAccent, secondary = pal.gold, onSecondary = pal.onAccent,
            background = pal.bg, onBackground = pal.ink, surface = pal.card, onSurface = pal.ink,
            surfaceVariant = pal.card, onSurfaceVariant = pal.muted, outline = pal.line, error = pal.bad,
            secondaryContainer = pal.accent.copy(alpha = 0.22f), onSecondaryContainer = pal.accent,
            surfaceContainer = pal.card, surfaceContainerLow = pal.card, surfaceContainerHigh = pal.card,
            surfaceContainerHighest = pal.card, surfaceContainerLowest = pal.card
        )
    } else {
        lightColorScheme(
            primary = pal.accent, onPrimary = pal.onAccent, secondary = pal.gold, onSecondary = pal.onAccent,
            background = pal.bg, onBackground = pal.ink, surface = pal.card, onSurface = pal.ink,
            surfaceVariant = pal.card, onSurfaceVariant = pal.muted, outline = pal.line, error = pal.bad,
            secondaryContainer = pal.accent.copy(alpha = 0.16f), onSecondaryContainer = pal.accent,
            surfaceContainer = pal.card, surfaceContainerLow = pal.card, surfaceContainerHigh = pal.card,
            surfaceContainerHighest = pal.card, surfaceContainerLowest = pal.card
        )
    }
    val view = LocalView.current
    SideEffect {
        val act = view.context as? Activity
        if (act != null) {
            WindowCompat.getInsetsController(act.window, view).isAppearanceLightStatusBars = !pal.dark
            WindowCompat.getInsetsController(act.window, view).isAppearanceLightNavigationBars = !pal.dark
        }
    }
    CompositionLocalProvider(LocalLV provides pal, LocalHeadFont provides head) {
        MaterialTheme(colorScheme = scheme, typography = typo, content = content)
    }
}
