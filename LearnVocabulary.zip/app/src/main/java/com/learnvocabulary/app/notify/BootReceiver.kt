package com.learnvocabulary.app.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.learnvocabulary.app.LearnApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Re-schedules alarms after reboot, time/timezone change, app update or exact-alarm permission change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val s = (app as LearnApp).repo.store.current()
                ReminderScheduler.syncAll(app, s)
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }
    }
}
