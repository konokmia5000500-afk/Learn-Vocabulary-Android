package com.learnvocabulary.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.learnvocabulary.app.LearnApp
import com.learnvocabulary.app.data.Settings
import com.learnvocabulary.app.data.WordRow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val la = app as LearnApp
    val repo = la.repo
    val tts = la.tts

    val settings: StateFlow<Settings?> =
        repo.settings.map<Settings, Settings?> { it }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val initDone = repo.initDone
    val initProgress = repo.initProgress
    val initError = repo.initError

    init {
        retryInit()
    }

    fun retryInit() {
        viewModelScope.launch { repo.ensureInit() }
    }

    fun speak(row: WordRow, withBn: Boolean) {
        val s = settings.value ?: return
        tts.speak(row.w, if (withBn) row.main else null, s)
    }

    fun speakWord(word: String) {
        val s = settings.value ?: return
        tts.speak(word, null, s)
    }

    fun stopSpeak() = tts.stop()

    fun setOverride(id: Int, lvl: Int) {
        viewModelScope.launch { repo.setOverride(id, lvl) }
    }

    fun setLater(id: Int, v: Boolean) {
        viewModelScope.launch { repo.setLater(id, v) }
    }

    fun studyKind(kind: Int, done: () -> Unit) {
        viewModelScope.launch {
            repo.studyKind(kind)
            done()
        }
    }

    fun learnNow(id: Int, done: () -> Unit) {
        viewModelScope.launch {
            repo.learnNow(id)
            done()
        }
    }

    fun continueToday(done: () -> Unit) {
        viewModelScope.launch {
            repo.continueToday()
            done()
        }
    }
}
